#include <stdio.h>
int main(void) {
    const int values[] = {-4, 7, 0, 7, -1};
    const size_t count = sizeof values / sizeof values[0];
    int minimum = values[0], maximum = values[0], sum = 0;
    for (size_t i = 0; i < count; ++i) {
        if (values[i] < minimum) minimum = values[i];
        if (values[i] > maximum) maximum = values[i];
        sum += values[i];
    }
    printf("Min: %d\nMax: %d\nMean: %.2f\n", minimum, maximum,
           (double)sum / (double)count);
    return 0;
}
