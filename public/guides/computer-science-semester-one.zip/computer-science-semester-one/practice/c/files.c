#include <stdio.h>
int main(void) {
    /* Run only inside a fresh sandbox: mode w replaces this practice file. */
    const char *path = "practice-marks.txt";
    FILE *out = fopen(path, "w");
    if (out == NULL) { perror("open for writing"); return 1; }
    if (fprintf(out, "70\n71\n73\n") < 0) {
        perror("write"); fclose(out); return 1;
    }
    if (fclose(out) != 0) { perror("close after writing"); return 1; }
    FILE *in = fopen(path, "r");
    if (in == NULL) { perror("open for reading"); return 1; }
    int mark, total = 0, count = 0;
    /* This reads a file produced above, not arbitrary untrusted integers. */
    while (fscanf(in, "%d", &mark) == 1) { total += mark; ++count; }
    if (ferror(in)) { perror("read"); fclose(in); return 1; }
    if (fclose(in) != 0) { perror("close after reading"); return 1; }
    printf("Count: %d\nTotal: %d\n", count, total);
    return 0;
}
