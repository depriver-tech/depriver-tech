#include <stdio.h>
static void swap(int *left, int *right) {
    int temporary = *left;
    *left = *right;
    *right = temporary;
}
int main(void) {
    int a = 3, b = 9;
    swap(&a, &b);
    printf("a=%d b=%d\n", a, b);
    return 0;
}
