#include <stdio.h>
int main(void) {
    const int marks[] = {70, 71, 73};
    const size_t count = sizeof marks / sizeof marks[0];
    int total = 0;
    for (size_t i = 0; i < count; ++i) total += marks[i];
    printf("Average: %.2f\n", (double)total / (double)count);
    return 0;
}
