#include <stdio.h>
struct Session { const char *subject; int minutes; };
int main(void) {
    const struct Session sessions[] = {
        {"Maths", 45}, {"C", 45}, {"Operating systems", 30}
    };
    const size_t count = sizeof sessions / sizeof sessions[0];
    int total = 0;
    for (size_t i = 0; i < count; ++i) total += sessions[i].minutes;
    printf("Sessions: %zu\nMinutes: %d\n", count, total);
    return 0;
}
