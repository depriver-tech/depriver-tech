#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void) {
    char line[128];
    if (fgets(line, sizeof line, stdin) == NULL) {
        fputs("Invalid mark\n", stderr); return 1;
    }
    if (strchr(line, '\n') == NULL && !feof(stdin)) {
        fputs("Invalid mark\n", stderr); return 1;
    }
    char *end;
    errno = 0;
    long mark = strtol(line, &end, 10);
    if (end == line || errno == ERANGE) {
        fputs("Invalid mark\n", stderr); return 1;
    }
    while (isspace((unsigned char)*end)) ++end;
    if (*end != '\0' || mark < 0 || mark > 100) {
        fputs("Invalid mark\n", stderr); return 1;
    }
    printf("Valid mark: %ld\n", mark);
    return 0;
}
