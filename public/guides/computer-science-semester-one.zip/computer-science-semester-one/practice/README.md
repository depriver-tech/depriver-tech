# Practice programs and safe labs

Six standalone C17 examples are in c/. The examples are deliberately small, use synthetic data and have no external library dependency. They are not production-ready general-purpose parsers or storage systems.

Run all checks with `python3 test_c_examples.py` from this directory. The runner finds clang or cc, compiles with strict warnings, and runs 15 execution cases in a new temporary directory. It verifies output, exit status and the invalid-mark error message. The file-writing example only writes inside that sandbox when run by the test runner.

For a single program, compile with `clang -std=c17 -Wall -Wextra -Wpedantic c/average.c -o average`, then run `./average`. For files.c, first create and enter a disposable directory; its fixed practice filename is opened in mode w, which replaces any existing file of that name.

Exercises: change the marks array and predict the mean; add a subject filter to study_logger.c; change array_stats.c to report a count of negative elements; extend marks.c with clearly specified requirements and new tests. Keep the original passing tests as regression checks.

## OS sandbox lab

Use a new practice folder of your own. Run pwd and ls before creating files. Create a notes directory, write a short text file with printf, read it with cat, copy it with cp and inspect permissions with ls -l. Change only your own practice file to mode 600 with chmod. Record which owner permissions remain. Inspect processes with ps; do not terminate services or change system files. Commands and output differ between Unix-like systems.

## Paper and simulator artifacts

- DFA: draw the ends-in-01 machine, write its transition table and trace five new strings.
- Digital: verify a half-adder truth table, then derive the output for every full-adder row.
- Electrical: solve a series-divider problem and a parallel-current problem; keep units in every substitution. Use paper/simulation only unless working in a supervised appropriate lab.
- Communication: write the test report for one C exercise, explicitly distinguishing what was tested from what remains untested.
