"""Compile original teaching examples and test them in disposable sandboxes."""
from pathlib import Path
import subprocess, tempfile, shutil
root = Path(__file__).resolve().parent / 'c'
compiler = shutil.which('clang') or shutil.which('cc')
if not compiler:
    raise SystemExit('Install a C compiler or run these in a school lab with one.')
cases = {
    'average': [('', 0, 'Average: 71.33\n')],
    'array_stats': [('', 0, 'Min: -4\nMax: 7\nMean: 1.80\n')],
    'pointers': [('', 0, 'a=9 b=3\n')],
    'files': [('', 0, 'Count: 3\nTotal: 214\n')],
    'study_logger': [('', 0, 'Sessions: 3\nMinutes: 120\n')],
    'marks': [(s, code, expected) for s, code, expected in [
        ('0\n',0,'Valid mark: 0\n'),('100\n',0,'Valid mark: 100\n'),
        (' 42 \n',0,'Valid mark: 42\n'),('-1\n',1,''),('101\n',1,''),
        ('abc\n',1,''),('42x\n',1,''),('',1,''),('\n',1,''),
        ('9'*200+'\n',1,'')]],
}
checked = 0
with tempfile.TemporaryDirectory(prefix='semester-c-') as directory:
    sandbox = Path(directory)
    for name, tests in cases.items():
        executable = sandbox/name
        subprocess.run([compiler,'-std=c17','-Wall','-Wextra','-Wpedantic','-Werror',
                        str(root/(name+'.c')),'-o',str(executable)],check=True)
        for data, status, expected in tests:
            result = subprocess.run([str(executable)],input=data,text=True,capture_output=True,cwd=sandbox)
            assert result.returncode == status, (name,data,result)
            assert result.stdout == expected, (name,data,result.stdout,expected)
            if status != 0:
                assert result.stderr == 'Invalid mark\n', (name,data,result.stderr)
            checked += 1
print(f'PASS: {len(cases)} programs compiled; {checked} execution cases passed.')
