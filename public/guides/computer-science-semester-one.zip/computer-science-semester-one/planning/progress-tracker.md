# Progress and error log

Copy a row for each lesson or practice session. The levels are self-assessment aids, not official grades.

| Date | Module and lesson | Independent artifact | Level | Error found | Correction | Next review |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |

## Weekly evidence checklist

- [ ] Maths: one solved problem with intermediate steps and a check.
- [ ] Communication: one revised explanation, report, email or presentation.
- [ ] Theory: one formal specification and a traced machine or proof argument.
- [ ] OS: one timeline, translation calculation or sandbox transcript.
- [ ] C: one compiled program with a new test.
- [ ] Digital: one verified truth table, simplification or state transition table.
- [ ] Electrical: one labeled paper/simulator circuit calculation with units.

## Error categories

Concept: I used the wrong model or definition. Procedure: I chose a valid method but executed a step incorrectly. Representation: I lost a unit, sign, bit width, index or state meaning. Communication: I could not explain the assumptions or justify the conclusion. Attention: I skipped a stated condition. Name the error before choosing the repair task.

## Lecturer-alignment log

| Date checked | Lecturer topic or requirement | Matching pack section | Additional class material needed |
| --- | --- | --- | --- |
| | | | |
