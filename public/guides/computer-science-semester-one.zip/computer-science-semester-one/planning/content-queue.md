# Learning-in-public content queue

This is an editorial backlog, not an automatic publishing schedule. Publish only after solving the example independently, checking the explanation and matching claims to the demonstrated work. Keep financial records, personal invoices, private class materials and other students' work out of public posts.

## Three finished articles prepared with this pack

- C integer division and average calculation: a complete standard-library example and a test that exposes the bug.
- DFA for strings ending in 01: state meanings, a transition table and accepted/rejected traces.
- Voltage/current/resistance: original single-resistor, series and parallel calculations with units.

## Twenty-four further post briefs

### Linear algebra and calculus
1. Why matrix multiplication is not element-by-element: two small matrices and a row-column calculation.
2. The derivative is a rate, not just a formula: a position/velocity example with units.
3. Limits at a missing point: factor a removable discontinuity and distinguish the value from the limit.
4. Distance versus displacement: use a velocity that changes sign and compare signed and absolute accumulation.

### Communication skills
5. A useful bug report in six lines: reproduce, expected, actual, environment and evidence.
6. Rewrite a vague lab conclusion: separate what was measured from what is merely assumed.
7. Explain one concept twice: a beginner audience and a technical audience, with a rationale for the changes.

### Theory of computation
8. Empty string versus empty language: show why they are different objects.
9. Even number of 1s: a two-state DFA and a state invariant.
10. Why one failed pumping split proves nothing: explain the order of choices without inventing a theorem.
11. Regex in theory versus regex in a programming tool: clearly state the syntax/model under discussion.

### Operating systems
12. Program, process and thread: one executable, two instances and shared versus separate resources.
13. FCFS versus round robin: a small timeline with arrival assumptions and response times.
14. Virtual page, frame and offset: one transparent address-translation calculation.
15. A lost update in four operations: trace two reads and two writes, then explain the protected invariant.

### Programming in C
16. The last array index: show a five-element example and an off-by-one failure.
17. Why a C string needs one more element: draw the zero terminator.
18. Parse a mark honestly: invalid text, boundaries, trailing junk and error reporting.
19. Swap values with pointers: draw the objects and explain their lifetimes.

### Digital circuits
20. Binary carry is not signed overflow: one four-bit example under two interpretations.
21. A multiplexer as a decision: derive Y=S'A+SB from the two select cases.
22. Build a half adder: enumerate every row before simplifying the output equations.

### Electrical fundamentals
23. An unloaded voltage divider and its assumption: calculate first, then explain how a load changes the model.
24. One RC time constant: calculate R*C and explain why the capacitor has not fully charged at that time.

## Repeatable publishing checklist

Choose one question; solve an original example; verify all numbers/types/units; state assumptions; link a useful primary source; include one independent practice task and its answer; check links and preview on mobile; avoid promising official examination coverage. For lab topics, keep public examples within safe paper/simulator practice unless proper supervised hardware work is explicitly documented.
