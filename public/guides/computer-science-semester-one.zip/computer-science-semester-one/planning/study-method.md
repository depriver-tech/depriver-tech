# A balanced twelve-week self-study pathway

This is a proposed supplement to classes, not an official university timetable or estimate of the total workload. Adapt around employment, travel, rest, lecturer deadlines and your actual weak areas. All seven modules receive equal dedicated practice in the starting rhythm.

## Session method

- 5 minutes: retrieve the last lesson without opening notes.
- 10 minutes: read one section and inspect the worked example.
- 20 minutes: solve or build something independently.
- 5 minutes: check against the answer, compiler, truth table or dimensional calculation.
- 5 minutes: record one error and write the next retrieval question.

Do not count a copied solution as independent success. Reattempt a related example on the next study day, about a week later, and later again as needed. These are adjustable review intervals, not a guaranteed retention formula.

## Starting weekly rhythm

Monday: maths 45 minutes and C 45 minutes. Tuesday: communication 45. Wednesday: theory 45. Thursday: OS 45. Friday: digital circuits 45. Saturday: electrical fundamentals 45 and mixed review 90. Sunday: rest or genuinely necessary catch-up. Total planned self-study is 6 hours 45 minutes, additional to classes. If this is too much, use 25-minute sessions and retain all seven subjects rather than silently dropping the difficult ones.

## The twelve-week route

Weeks 1-8: take the matching numbered lesson in each of the seven modules. For example, Week 3 covers matrices, paragraphs, DFA state meaning, scheduling, C selection, logic gates and series circuits. The sequencing is for these notes; if your lecturer teaches another order, follow the class sequence and use the corresponding lesson here.

Week 9: complete all 12 questions per module without the answer sections. Divide them across the week. Record which answers required a hint. Review the underlying lesson before repeating the missed skill with different numbers or inputs.

Week 10: work on the integrated mini-project below, and explain it in writing. Keep ordinary topic revision active rather than devoting the entire week to cosmetic presentation.

Week 11: make your own mixed mock assessment: 20 minutes maths, 20 C, 20 theory, 20 OS, 20 digital, 20 electrical and 20 communication. These are practice intervals, not predictions about the university's examination pattern. Mark with the included answer guides and retain the work.

Week 12: repair the three weakest skills across the diagnostic results. Re-solve a fresh version from a blank page. Explain the correction aloud, and update a one-page formula/concept sheet using only items you can justify.

## Integrated project | A small study-session logger

Use synthetic data, not personal records. Start with the supplied C study_logger.c. Then add one clearly scoped feature: a subject filter, validated entry input, or a report written to a sandbox file.

- Maths: calculate total and mean minutes; explain integer versus real-valued division.
- Communication: write a one-page README and a short test report with audience and purpose.
- Theory: draw a small state machine for input states such as waiting, valid entry and error. State what your model abstracts away.
- OS: explain where the program executes as a process, which files it opens, and the permissions needed.
- C: separate data, calculation and presentation; test the chosen feature.
- Digital: draw a truth table for a status indicator based on two defined Boolean inputs, such as target-met and invalid-entry. Explain the intended output.
- Electrical: design a paper-only resistor calculation for a hypothetical low-voltage indicator load using explicit component assumptions. Do not connect hardware as part of this self-study project.

Deliverables: source code, test results, a labeled diagram, a calculation page, a one-page report and a three-minute explanation. No fabricated measurements or claims of external deployment.

## What counts as progress

Use five levels: not attempted; can follow; can solve with notes; can solve independently; can explain and transfer. A topic is not mastered because its video has played to the end. Keep a record of the independent artifact that supports your current level.
