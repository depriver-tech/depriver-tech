# Retrieval cards | Answer before turning back to the notes

## Maths
- What determines whether matrix multiplication is defined? Inner dimensions must match.
- How do you check a linear-system solution? Substitute into every original equation.
- Why can a limit exist where a function is undefined? Nearby behavior can approach one value even when the value at the point is missing.
- What is missing from d((2x+1)^3)/dx = 3(2x+1)^2? The inner derivative factor 2.
- How do distance and displacement differ in integration? Distance accumulates speed; displacement accumulates signed velocity.

## Communication
- What three questions start a useful explanation? Audience, existing knowledge and intended understanding/action.
- How do results differ from discussion? Results record findings; discussion interprets them and their limitations.
- Does paraphrasing remove the need to cite? No.
- What makes feedback actionable? A specific feature, its effect and a feasible correction.
- Why keep first drafts? To identify what changed and whether revision improved the intended result.

## Theory
- How is the empty string different from the empty language? One is a length-zero string; the other contains no strings.
- When does a DFA accept? After all input is consumed, its state is accepting.
- How does an NFA accept? At least one complete input-consuming path ends in an accepting state.
- What does a state in subset construction represent? A set of possible NFA states.
- Can the pumping lemma prove regularity by finding one pumpable string? No.

## Operating systems
- How are program and process different? A stored program is not its executing instance.
- What is response time? First execution time minus arrival time.
- What is preserved when a page maps to a frame? The page offset.
- Why can two increments lose an update? Both can read the same old value before either writes.
- What does a directory execute bit generally permit on Unix-like systems? Traversal, subject to other access rules.

## C
- What does 7/2 produce with integer operands? 3.
- Why does assigning integer division to double not repair it? The fractional part was already discarded.
- What ends a C string? A zero byte, '\0'.
- What is the last valid index of n elements? n-1 when n>0.
- What must a pointer refer to before a write through it? A valid live writable object of a suitable type.

## Digital circuits
- How many bits correspond to one hex digit? Four.
- What distinguishes signed overflow from carry-out? They concern different interpretations and conditions.
- What does XOR produce for inputs 1 and 1? 0.
- What does a 2:1 multiplexer do? Select one input according to its control bit.
- Why does a truth table not settle timing correctness? It describes stable logic, not propagation/setup/hold constraints.

## Electrical fundamentals
- What does voltage measure? Energy per unit charge.
- Which resistor formula assumes ohmic behavior? V=IR with an appropriate constant resistance model.
- What is shared by parallel branches? Voltage across their common nodes.
- What is an RC time constant? R*C in seconds.
- Is an ammeter connected across an ideal source a valid voltage measurement? No; it can create a short circuit.
