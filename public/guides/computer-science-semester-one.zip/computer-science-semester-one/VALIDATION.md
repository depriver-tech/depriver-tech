# Validation record | 18 November 2026

- Seven module names/codes checked against the supplied MUST Prospectus 2025/2026, printed page 173.
- 56 numbered lessons, 12 practice questions per module, and answer guides for all 84 questions.
- Six C17 programs compiled with Clang and -Wall -Wextra -Wpedantic -Werror; 15 execution cases passed in disposable sandboxes.
- 1,080 independent numerical, automata and logic assertions passed. These include all binary strings through length eight for the two DFA examples, matrix examples, Boolean/addition tables, memory arithmetic and selected circuit calculations.
- The 39-page PDF was rendered and visually inspected through a complete contact sheet and representative full-size pages. Cover, contents, diagrams, tables and reference links were checked. First-edition proofreading does not make the pack official courseware.
- The PDF's reference links were checked for complete URL targets after generation.
- Communication answers are rubrics and examples; they are not uniquely correct responses. Timetables are proposals, not an agreed personal schedule.
- Alignment with the 2026/2027 lecturer outlines, examination format and laboratory procedures remains to be confirmed.
