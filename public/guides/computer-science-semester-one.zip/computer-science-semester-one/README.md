# Computer Science Foundations | Semester One

Prepared for Privatus Cosmas, 18 November 2026. Covers the seven first-semester modules evenly: 56 foundation lessons and 84 practice questions with answer guides. Notes and examples are original. External resources are linked for further learning rather than redistributed.

## Start here

1. Read planning/study-method.md and choose a realistic weekly rhythm.
2. Work through one lesson, close it, reconstruct the explanation and solve a fresh example.
3. Complete the practice set before checking the answer section.
4. Compile and run the C examples in practice/c; see practice/README.md.
5. Record evidence and weaknesses in planning/progress-tracker.md.

The printable book is computer-science-semester-one.pdf. Individual editable chapters are under notes/. Planning files, flashcards and original practice programs are included in this package.

## Module index

| Code | Module | File |
| --- | --- | --- |
| MS 8121 | Linear Algebra and Calculus | notes/01-linear-algebra-and-calculus.md |
| HS 8101 | Communication Skills | notes/02-communication-skills.md |
| CS 8101 | Theory of Computation | notes/03-theory-of-computation.md |
| CS 8140 | Operating Systems | notes/04-operating-systems.md |
| CS 8138 | Programming Concepts in C | notes/05-programming-concepts-in-c.md |
| CS 8102 | Basics in Digital Circuit | notes/06-basics-in-digital-circuit.md |
| CS 8103 | Electrical Fundamentals | notes/07-electrical-fundamentals.md |

## Scope and provenance

The names and codes were checked against the supplied MUST Prospectus 2025/2026, printed page 173. That prospectus is older than the 2026/2027 intake. Module titles do not specify every assessed topic, so this pack is a substantial foundation course, not an official MUST textbook, current syllabus or promise of examination coverage. Match it to your lecturer's outlines, timetable and assignments when available.

This edition focuses its detailed lessons on the seven first-semester modules. It does not present later-year modules as completed notes. Use the current course outlines to identify any additional topics or assessment requirements.

The package contains original notes, exercises and code. External textbooks and original university documents are not redistributed. Public companion articles use original educational examples.

## Learning resources

- Maths: MIT 18.06, https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/ ; OpenStax Calculus, https://openstax.org/books/calculus-volume-1/pages/preface .
- Communication: Google Technical Writing One, https://developers.google.com/tech-writing/one ; Purdue OWL, https://owl.purdue.edu/owl/general_writing/academic_writing/paragraphs_and_paragraphing/index.html .
- Theory: MIT 6.045J, https://ocw.mit.edu/courses/6-045j-automata-computability-and-complexity-spring-2011/ .
- OS: the authors' OSTEP site, https://pages.cs.wisc.edu/~remzi/OSTEP/ .
- C: Harvard CS50, https://cs50.harvard.edu/x/weeks/1/ ; WG14 C11-era committee draft N1570, https://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf . The examples use C17 mode; N1570 is a precision reference for shared foundations, not a current-edition tutorial.
- Digital: MIT Computation Structures, https://ocw.mit.edu/courses/6-004-computation-structures-spring-2017/ .
- Electrical: MIT Circuits, https://ocw.mit.edu/courses/6-002-circuits-and-electronics-spring-2007/ ; OpenStax Physics, https://openstax.org/books/university-physics-volume-2/pages/9-1-electrical-current .

Links checked 18 November 2026. Availability and course editions can change. Download third-party materials from their own sites subject to their terms; this package does not relicense them.
