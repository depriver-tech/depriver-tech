"""Independent arithmetic, automata and truth-table checks for the original examples."""
from itertools import product
from math import isclose, sqrt, exp
checks=0

def equal(actual, expected):
    global checks
    assert actual == expected, (actual, expected)
    checks+=1

def near(actual,expected):
    global checks
    assert isclose(actual,expected,rel_tol=1e-10,abs_tol=1e-10),(actual,expected)
    checks+=1

# Matrices and systems from the maths notes.
A=[[1,2],[0,1]]; B=[[2,0],[3,1]]
def multiply(a,b):return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]
equal(multiply(A,B),[[8,2],[3,1]])
equal(multiply(B,A),[[2,4],[3,7]])
equal(multiply([[2,1],[1,1]],[[1,-1],[-1,2]]),[[1,0],[0,1]])
equal((3+2*2,3*3+2),(7,11))
equal((2*3+2,3-2),(8,1))
near(sqrt(6**2+8**2),10)
equal((2**3+2*2),12)
# Every binary string up to length eight, not just the examples in the notes.
ends={'q0':{'0':'q1','1':'q0'},'q1':{'0':'q1','1':'q2'},'q2':{'0':'q1','1':'q0'}}
for length in range(9):
    for bits in product('01',repeat=length):
        word=''.join(bits); state='q0'; even=True
        for symbol in word:
            state=ends[state][symbol]
            if symbol=='1':even=not even
        equal(state=='q2',word.endswith('01'))
        equal(even,word.count('1')%2==0)
# Boolean equivalences and adders.
for a,b,c in product((0,1),repeat=3):
    equal((a and b) or (a and not b),bool(a))
    equal((a^b)^c,(a+b+c)%2)
    equal(int((a and b) or (c and (a^b))),(a+b+c)//2)
    equal(bool(((a<<2)|(b<<1)|c) in (1,3,5,7)),bool(c))
# Memory translation and scheduling totals.
equal(divmod(10000,4096),(2,1808));equal(7*4096+1808,30480)
equal(divmod(3500,1024),(3,428));equal(5*1024+428,5548)
equal([4-0,6-1,7-2],[4,5,5]);equal([4-4,5-2,5-1],[0,3,4])
# Resistor, divider, RC and AC calculations.
near(5/1000,.005);near(5*.005,.025);near(12/6000,.002)
near((3000*6000)/(3000+6000),2000)
near(10/2000+10/5000,.007);near(8*1000/4000,2)
near((8-12)/2000+8/4000,0)
near(10000*.0001,1);near(5000*.0002,1)
near(5*(1-exp(-1)),3.1606027941427883)
near(10*(1-exp(-1)),6.321205588285577)
near((10/sqrt(2))**2/100,.5);near(1/100,.01)
print(f'PASS: {checks} independent numerical/automata/logic assertions.')
