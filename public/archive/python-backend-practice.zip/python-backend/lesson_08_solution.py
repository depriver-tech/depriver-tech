# Python for Backend: Transactions and rollback
import sqlite3
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE stock(id INTEGER PRIMARY KEY, qty INTEGER)")
con.execute("INSERT INTO stock VALUES (1, 1)")
con.commit()
def reserve():
    with con:
        result = con.execute("UPDATE stock SET qty=qty-1 "
                             "WHERE id=1 AND qty>0")
        return result.rowcount == 1
assert reserve()
assert not reserve()
assert con.execute("SELECT qty FROM stock").fetchone()[0] == 0
con.close()
