# Python for Backend: Idempotency and retries
results = {}
def create_once(key, title):
    if key in results:
        old_title, result = results[key]
        if old_title != title:
            raise ValueError("Key reused with different input")
        return result
    result = {"id": len(results) + 1, "title": title}
    results[key] = (title, result)
    return result
assert create_once("abc", "Read") == create_once("abc", "Read")
assert len(results) == 1
