# Python for Backend: Project: a task API
from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import BaseModel, Field, ConfigDict
class TaskInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    title: str = Field(min_length=1, max_length=80)
app = FastAPI()
tasks = {}
@app.post("/tasks", status_code=201)
def create(body: TaskInput):
    ident = len(tasks) + 1
    tasks[ident] = {"id": ident, "title": body.title}
    return tasks[ident]
c = TestClient(app)
assert c.post("/tasks", json={"title": " Read "}).json() == {
    "id": 1, "title": "Read"}
assert c.post("/tasks", json={"title": " "}).status_code == 422
