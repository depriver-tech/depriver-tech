# Python for Backend: Pagination and filters
def page(rows, cursor=0, limit=2):
    if not 1 <= limit <= 100:
        raise ValueError("Invalid limit")
    found = [r for r in sorted(rows, key=lambda r: r["id"])
             if r["id"] > cursor][:limit+1]
    items = found[:limit]
    nxt = items[-1]["id"] if len(found) > limit else None
    return {"items": items, "next_cursor": nxt}
rows = [{"id": 1}, {"id": 2}, {"id": 3}]
assert page(rows)["next_cursor"] == 2
assert page(rows, 2)["next_cursor"] is None
assert page([])["items"] == []
