# Python for Backend: Flask JSON endpoints
from flask import Flask
app = Flask(__name__)
@app.get("/health")
def health():
    return {"status": "ok"}
c = app.test_client()
r = c.get("/health")
assert r.status_code == 200
assert r.is_json
assert r.json == {"status": "ok"}
