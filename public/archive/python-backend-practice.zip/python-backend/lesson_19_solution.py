# Python for Backend: Tests at different boundaries
from fastapi import FastAPI
from fastapi.testclient import TestClient
app = FastAPI()
@app.get("/total")
def total(a: int, b: int):
    return {"total": a + b}
c = TestClient(app)
assert c.get("/total?a=2&b=3").json() == {"total": 5}
assert c.get("/total?a=x&b=3").status_code == 422
assert c.get("/total?a=2").status_code == 422
