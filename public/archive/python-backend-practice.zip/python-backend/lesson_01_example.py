# Python for Backend: Design an API contract
contract = {
    "GET /tasks": {"status": 200, "body": {"items": []}},
    "POST /tasks": {"status": 201, "required": ["title"]},
    "GET /tasks/unknown": {"status": 404},
}
assert contract["POST /tasks"]["status"] == 201
assert "title" in contract["POST /tasks"]["required"]
