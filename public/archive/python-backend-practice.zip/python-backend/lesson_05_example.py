# Python for Backend: Response models
from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import BaseModel
class PublicUser(BaseModel):
    id: int
    name: str
app = FastAPI()
@app.get("/me", response_model=PublicUser)
def me():
    return {"id": 1, "name": "Asha", "secret": "internal"}
r = TestClient(app).get("/me")
assert r.json() == {"id": 1, "name": "Asha"}
