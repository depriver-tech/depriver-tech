# Python for Backend: Request models
from pydantic import BaseModel, Field, ConfigDict
class TaskInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str = Field(min_length=2, max_length=80)
    priority: int = Field(ge=1, le=5)

task = TaskInput(title="Learn", priority=2)
assert task.priority == 2
assert task.model_dump()["title"] == "Learn"
