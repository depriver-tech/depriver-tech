# Python for Backend: Logs and error handling
import json
record = {"event": "task_created", "request_id": "req-1",
          "task_id": 7, "status": 201}
line = json.dumps(record, sort_keys=True)
assert json.loads(line)["request_id"] == "req-1"
assert "password" not in line
