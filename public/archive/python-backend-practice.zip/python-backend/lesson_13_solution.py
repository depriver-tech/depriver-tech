# Python for Backend: Dependencies and test doubles
from fastapi import FastAPI, Depends
from fastapi.testclient import TestClient
app = FastAPI()
def repository():
    return {"title": "Default"}
@app.get("/task")
def task(record=Depends(repository)):
    return record
app.dependency_overrides[repository] = lambda: {"title": "Test"}
assert TestClient(app).get("/task").json() == {"title": "Test"}
app.dependency_overrides.clear()
