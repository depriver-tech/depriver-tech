# Python for Backend: Caching and invalidation
class Cache:
    def __init__(self):
        self.data = {}
    def put(self, key, value, now, ttl):
        self.data[key] = (value, now + ttl)
    def get(self, key, now):
        value, expiry = self.data.get(key, (None, 0))
        return value if now < expiry else None
c = Cache()
c.put("public", "report", now=10, ttl=5)
assert c.get("public", 14) == "report"
assert c.get("public", 15) is None
assert c.get("missing", 14) is None
