# Python for Backend: Authentication boundaries
from hmac import compare_digest

def authenticated(expected, supplied):
    return bool(expected and supplied) and compare_digest(
        expected, supplied)
assert authenticated("local-demo-key", "local-demo-key")
assert not authenticated("local-demo-key", "wrong")
assert not authenticated("", "")
