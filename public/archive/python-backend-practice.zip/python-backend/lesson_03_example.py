# Python for Backend: FastAPI and typed paths
from fastapi import FastAPI
from fastapi.testclient import TestClient
app = FastAPI()
@app.get("/double/{value}")
def double(value: int):
    return {"result": value * 2}
c = TestClient(app)
assert c.get("/double/3").json() == {"result": 6}
assert c.get("/double/abc").status_code == 422
