# Python for Backend: Dependencies and test doubles
def report(clock):
    return {"generated_at": clock(), "status": "ok"}
assert report(lambda: "2026-10-19T00:00:00Z") == {
    "generated_at": "2026-10-19T00:00:00Z", "status": "ok"}
