# Python for Backend: Request models
from pydantic import BaseModel, Field, ConfigDict, ValidationError
class TaskInput(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    title: str = Field(min_length=1, max_length=80)
assert TaskInput(title="  Learn  ").title == "Learn"
for data in [{"title": "   "}, {"title": "A", "unknown": 1}]:
    try:
        TaskInput(**data)
    except ValidationError:
        pass
    else:
        raise AssertionError("Invalid payload accepted")
