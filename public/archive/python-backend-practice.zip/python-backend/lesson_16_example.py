# Python for Backend: Caching and invalidation
def cache_key(user_id, filters):
    return user_id, tuple(sorted(filters.items()))
assert cache_key(1, {"done": False}) != cache_key(2, {"done": False})
assert cache_key(1, {"a": 1, "b": 2}) == cache_key(1, {"b": 2, "a": 1})
