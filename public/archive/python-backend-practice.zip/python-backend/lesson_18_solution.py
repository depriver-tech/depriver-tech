# Python for Backend: Configuration and releases
def allowed_origins(raw):
    origins = [part.strip() for part in raw.split(",") if part.strip()]
    if not origins or "*" in origins:
        raise ValueError("Explicit origins required")
    return origins
assert allowed_origins("https://a.test, https://b.test") == [
    "https://a.test", "https://b.test"]
for raw in ["", "*"]:
    try:
        allowed_origins(raw)
    except ValueError:
        pass
    else:
        raise AssertionError("Invalid origin policy")
