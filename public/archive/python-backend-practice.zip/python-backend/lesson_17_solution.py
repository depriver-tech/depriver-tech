# Python for Backend: Logs and error handling
def redact(record):
    sensitive = {"token", "password", "authorization"}
    return {key: "[redacted]" if key.casefold() in sensitive else value
            for key, value in record.items()}
source = {"token": "secret", "event": "login"}
clean = redact(source)
assert clean == {"token": "[redacted]", "event": "login"}
assert source["token"] == "secret"
