# Python for Backend: Design an API contract
def success(ident, title):
    return {"item": {"id": ident, "title": title}}
def missing():
    return {"error": {"code": "not_found",
                      "message": "Task not found"}}
assert success(1, "Learn")["item"]["id"] == 1
assert missing()["error"]["code"] == "not_found"
assert "traceback" not in str(missing()).lower()
