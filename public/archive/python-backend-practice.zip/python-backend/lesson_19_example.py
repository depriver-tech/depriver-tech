# Python for Backend: Tests at different boundaries
def total(amounts):
    if any(value < 0 for value in amounts):
        raise ValueError("Negative amount")
    return sum(amounts)
assert total([]) == 0
assert total([2, 3]) == 5
try:
    total([-1])
except ValueError:
    pass
else:
    raise AssertionError("Negative amount accepted")
