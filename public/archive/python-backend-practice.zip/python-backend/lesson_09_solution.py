# Python for Backend: Authentication boundaries
from fastapi import FastAPI, Header, Depends, HTTPException
from fastapi.testclient import TestClient
from hmac import compare_digest
app = FastAPI()
def owner(x_api_key: str = Header(default="")):
    if not compare_digest(x_api_key, "local-demo-key"):
        raise HTTPException(401, "Authentication required")
@app.get("/private", dependencies=[Depends(owner)])
def private():
    return {"ok": True}
c = TestClient(app)
assert c.get("/private").status_code == 401
assert c.get("/private", headers={"X-API-Key": "wrong"}).status_code == 401
assert c.get("/private", headers={
    "X-API-Key": "local-demo-key"}).status_code == 200
