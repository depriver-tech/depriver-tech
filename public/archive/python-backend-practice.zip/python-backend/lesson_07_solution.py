# Python for Backend: Persistence and SQL
import sqlite3
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE tasks(title TEXT UNIQUE)")
con.execute("INSERT INTO tasks VALUES (?)", ("Read",))
con.commit()
try:
    con.execute("INSERT INTO tasks VALUES (?)", ("Read",))
    con.commit()
except sqlite3.IntegrityError:
    con.rollback()
assert con.execute("SELECT COUNT(*) FROM tasks").fetchone()[0] == 1
con.close()
