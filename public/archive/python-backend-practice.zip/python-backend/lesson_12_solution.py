# Python for Backend: Idempotency and retries
def retry(operation, attempts=3):
    if attempts < 1:
        raise ValueError("At least one attempt")
    for attempt in range(attempts):
        try:
            return operation()
        except TimeoutError:
            if attempt == attempts - 1:
                raise
calls = []
def flaky():
    calls.append(1)
    if len(calls) < 3:
        raise TimeoutError()
    return "ok"
assert retry(flaky) == "ok"
assert len(calls) == 3
