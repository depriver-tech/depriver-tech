# Python for Backend: Configuration and releases
def settings(env):
    database = env.get("DATABASE_URL")
    if not database:
        raise ValueError("DATABASE_URL is required")
    return {"database_url": database,
            "debug": env.get("DEBUG", "false").lower() == "true"}
assert settings({"DATABASE_URL": "sqlite:///local.db"})["debug"] is False
