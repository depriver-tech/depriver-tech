# Python for Backend - practice files

By Privatus Cosmas (Priver), depriver.tech. Companion to the 64-page notebook.

## Setup

Create a virtual environment using python -m venv .venv. Activate it with source .venv/bin/activate on macOS/Linux or .venv\Scripts\activate.bat in Windows Command Prompt. Install the packages below. Run each file independently; framework examples include in-process requests. Never deploy hardcoded demonstration credentials.

```sh
python -m pip install Flask "fastapi[standard]" httpx
python lesson_01_example.py
python lesson_01_solution.py
```

Create a virtual environment before installing third-party packages:

```sh
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
```

There are 20 example scripts and 20 matching solutions. Run each file on its own.
Most successful checks print nothing; a failed assertion produces a traceback.
Read the lesson before its solution. lesson.md provides the complete text.

These are local educational fixtures. No live service credentials are needed.
Tests establish the demonstrated examples, not production readiness. Browser,
network, deployment and security review remain separate work for a real app.

## Official references

- [Flask API](https://flask.palletsprojects.com/en/stable/api/)
- [FastAPI tutorial](https://fastapi.tiangolo.com/tutorial/)
- [FastAPI security](https://fastapi.tiangolo.com/tutorial/security/)
- [FastAPI deployment](https://fastapi.tiangolo.com/deployment/)
- [SQLite transactions](https://docs.python.org/3/library/sqlite3.html)
- [HTTP semantics](https://www.rfc-editor.org/rfc/rfc9110.html)
