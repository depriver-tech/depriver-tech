# Python for Backend: Async without confusion
import asyncio
async def main():
    limit = asyncio.Semaphore(2)
    active = peak = 0
    async def work(value):
        nonlocal active, peak
        async with limit:
            active += 1
            peak = max(peak, active)
            try:
                await asyncio.sleep(0)
                return value * 2
            finally:
                active -= 1
    result = await asyncio.gather(*(work(i) for i in range(5)))
    assert peak <= 2 and active == 0
    return result
assert asyncio.run(main()) == [0, 2, 4, 6, 8]
