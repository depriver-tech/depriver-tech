# Python for Backend: FastAPI and typed paths
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
app = FastAPI()
@app.get("/square/{value}")
def square(value: int):
    if value < 0:
        raise HTTPException(400, "Use a non-negative value")
    return {"result": value * value}
c = TestClient(app)
assert c.get("/square/4").json()["result"] == 16
assert c.get("/square/0").json()["result"] == 0
assert c.get("/square/-1").status_code == 400
assert c.get("/square/text").status_code == 422
