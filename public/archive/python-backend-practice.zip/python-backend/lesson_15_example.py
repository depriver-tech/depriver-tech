# Python for Backend: Background jobs
jobs = {}
def submit(ident):
    jobs.setdefault(ident, {"state": "queued", "attempts": 0})
    return {"job_id": ident, "state": jobs[ident]["state"]}
assert submit("report-1")["state"] == "queued"
assert submit("report-1")["job_id"] == "report-1"
assert len(jobs) == 1
