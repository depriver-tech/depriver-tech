# Python for Backend: Flask JSON endpoints
from flask import Flask
app = Flask(__name__)
@app.get("/items/<int:ident>")
def item(ident):
    if ident != 1:
        return {"error": "not_found"}, 404
    return {"id": 1, "title": "Notebook"}
c = app.test_client()
assert c.get("/items/1").json["title"] == "Notebook"
r = c.get("/items/99")
assert r.status_code == 404 and r.is_json
