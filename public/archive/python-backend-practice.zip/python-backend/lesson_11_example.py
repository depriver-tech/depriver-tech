# Python for Backend: Pagination and filters
def after_id(rows, cursor=0, limit=2):
    if not 1 <= limit <= 100:
        raise ValueError("Limit must be 1-100")
    ordered = sorted(rows, key=lambda row: row["id"])
    return [row for row in ordered if row["id"] > cursor][:limit]
rows = [{"id": 3}, {"id": 1}, {"id": 2}]
assert after_id(rows, 1) == [{"id": 2}, {"id": 3}]
