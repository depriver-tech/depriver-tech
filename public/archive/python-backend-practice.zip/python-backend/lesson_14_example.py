# Python for Backend: Async without confusion
import asyncio
async def fetch_label(label):
    await asyncio.sleep(0)
    return label.upper()
async def main():
    return await asyncio.gather(fetch_label("a"), fetch_label("b"))
assert asyncio.run(main()) == ["A", "B"]
