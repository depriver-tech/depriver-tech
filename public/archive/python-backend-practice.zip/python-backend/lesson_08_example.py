# Python for Backend: Transactions and rollback
import sqlite3
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE stock(id INTEGER PRIMARY KEY, qty INTEGER)")
con.execute("INSERT INTO stock VALUES (1, 5)")
con.commit()
try:
    with con:
        con.execute("UPDATE stock SET qty = qty - 1 WHERE id = 1")
        raise RuntimeError("Simulated failure")
except RuntimeError:
    pass
assert con.execute("SELECT qty FROM stock").fetchone()[0] == 5
con.close()
