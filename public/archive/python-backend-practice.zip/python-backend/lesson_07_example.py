# Python for Backend: Persistence and SQL
import sqlite3
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE tasks (id INTEGER PRIMARY KEY, "
            "title TEXT NOT NULL UNIQUE)")
con.execute("INSERT INTO tasks(title) VALUES (?)", ("Read",))
con.commit()
assert con.execute("SELECT title FROM tasks").fetchone() == ("Read",)
con.close()
