# Python for Backend: Response models
from pydantic import BaseModel
class PublicTask(BaseModel):
    id: int
    title: str
    done: bool
internal = {"id": 1, "title": "Read", "done": False,
            "owner_token": "private"}
public = PublicTask(**internal).model_dump()
assert public == {"id": 1, "title": "Read", "done": False}
assert "owner_token" not in public
