# Python for Backend: Authorisation and ownership
def find_owned(tasks, ident, user_id):
    task = tasks.get(ident)
    if task is None or task["owner_id"] != user_id:
        return None
    return task

tasks = {1: {"id": 1, "owner_id": 7, "title": "Read"}}
assert find_owned(tasks, 1, 7)["title"] == "Read"
assert find_owned(tasks, 1, 8) is None
assert find_owned(tasks, 99, 7) is None
