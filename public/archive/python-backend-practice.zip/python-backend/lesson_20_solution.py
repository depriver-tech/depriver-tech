# Python for Backend: Project: a task API
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from pydantic import BaseModel, Field, ConfigDict
class TaskInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    title: str = Field(min_length=1, max_length=80)
app, tasks = FastAPI(), {}
@app.post("/tasks", status_code=201)
def create(body: TaskInput):
    ident = len(tasks) + 1
    tasks[ident] = {"id": ident, "title": body.title}
    return tasks[ident]
@app.get("/tasks/{ident}")
def read(ident: int):
    if ident not in tasks:
        raise HTTPException(404, "Task not found")
    return tasks[ident]
c = TestClient(app)
r = c.post("/tasks", json={"title": "Learn"})
assert r.status_code == 201
assert c.get("/tasks/1").json()["title"] == "Learn"
assert c.get("/tasks/99").status_code == 404
assert c.post("/tasks", json={"title": " "}).status_code == 422
