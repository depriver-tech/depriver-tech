# Python for Backend: Authorisation and ownership
def can_read(user_id, task):
    return task["owner_id"] == user_id

task = {"id": 9, "owner_id": 2, "title": "Private"}
assert can_read(2, task)
assert not can_read(3, task)
