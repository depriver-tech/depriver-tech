# Python for Backend: Separate service logic
def complete(task):
    if task["done"]:
        raise ValueError("Already completed")
    return {**task, "done": True}
original = {"id": 1, "done": False}
updated = complete(original)
assert updated["done"] and not original["done"]
try:
    complete(updated)
except ValueError:
    pass
else:
    raise AssertionError("Repeated transition accepted")
