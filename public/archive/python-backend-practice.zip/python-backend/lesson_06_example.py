# Python for Backend: Separate service logic
def create_task(title, priority):
    title = title.strip()
    if not title:
        raise ValueError("Title required")
    if priority not in range(1, 6):
        raise ValueError("Priority must be 1-5")
    return {"title": title, "priority": priority, "done": False}
assert create_task("  Learn  ", 2)["title"] == "Learn"
