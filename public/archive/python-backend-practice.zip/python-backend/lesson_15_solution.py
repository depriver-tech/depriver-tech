# Python for Backend: Background jobs
ALLOWED = {"queued": {"running"},
           "running": {"succeeded", "failed"},
           "succeeded": set(), "failed": set()}
def transition(job, state):
    if state not in ALLOWED[job["state"]]:
        raise ValueError("Invalid transition")
    return {**job, "state": state}
job = transition({"state": "queued"}, "running")
job = transition(job, "succeeded")
assert job["state"] == "succeeded"
try:
    transition(job, "running")
except ValueError:
    pass
else:
    raise AssertionError("Transition accepted")
