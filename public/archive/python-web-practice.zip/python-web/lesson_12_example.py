# Python for Web: Database-backed pages
import sqlite3
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE lessons (id INTEGER, title TEXT)")
con.executemany("INSERT INTO lessons VALUES (?, ?)",
                [(1, "Git"), (2, "Python")])
rows = con.execute("SELECT id, title FROM lessons ORDER BY id")
assert list(rows) == [(1, "Git"), (2, "Python")]
con.close()
