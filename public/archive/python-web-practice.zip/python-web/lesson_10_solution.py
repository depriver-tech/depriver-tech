# Python for Web: Redirect after submission
from flask import Flask, redirect
app = Flask(__name__)
@app.post("/submit")
def submit():
    return redirect("/thanks", code=303)
@app.get("/thanks")
def thanks():
    return "Thank you"
r = app.test_client().post("/submit", follow_redirects=True)
assert r.text == "Thank you"
assert len(r.history) == 1
assert r.history[0].status_code == 303
