# Python for Web: CSRF and form intent
from hmac import compare_digest

def add_note(notes, text, expected, supplied):
    if not expected or not supplied:
        raise PermissionError("Missing CSRF token")
    if not compare_digest(expected, supplied):
        raise PermissionError("Invalid CSRF token")
    notes.append(text)

notes = []
add_note(notes, "Learn", "demo-token", "demo-token")
try:
    add_note(notes, "Bad", "demo-token", "wrong")
except PermissionError:
    pass
assert notes == ["Learn"]
