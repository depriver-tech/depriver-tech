# Python for Web: CSRF and form intent
import secrets
from hmac import compare_digest

def valid_csrf(expected, supplied):
    return bool(expected and supplied) and compare_digest(
        expected, supplied)

token = secrets.token_urlsafe(32)
assert valid_csrf(token, token)
assert not valid_csrf(token, "wrong")
assert not valid_csrf("", "")
