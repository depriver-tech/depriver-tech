# Python for Web: Redirect after submission
from flask import Flask, redirect, url_for
app = Flask(__name__)
@app.post("/submit")
def submit():
    return redirect(url_for("thanks"), code=303)
@app.get("/thanks")
def thanks():
    return "Thank you"
c = app.test_client()
r = c.post("/submit")
assert r.status_code == 303
assert r.headers["Location"] == "/thanks"
