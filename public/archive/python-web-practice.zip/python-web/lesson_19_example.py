# Python for Web: Testing and release checks
from flask import Flask

def create_app(testing=False):
    app = Flask(__name__)
    app.config["TESTING"] = testing
    @app.get("/health")
    def health():
        return {"status": "ok"}
    return app

app = create_app(True)
assert app.test_client().get("/health").json == {"status": "ok"}
