# Python for Web: Static files and caching
from flask import Flask, make_response
app = Flask(__name__)
@app.get("/notice.txt")
def notice():
    response = make_response("New guide available")
    response.headers["Content-Type"] = "text/plain; charset=utf-8"
    response.headers["Cache-Control"] = "public, max-age=60"
    return response
r = app.test_client().get("/notice.txt")
assert r.status_code == 200
assert "max-age=60" in r.headers["Cache-Control"]
