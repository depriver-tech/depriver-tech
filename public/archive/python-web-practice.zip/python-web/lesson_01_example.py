# Python for Web: A request becomes a response
from flask import Flask
app = Flask(__name__)

@app.get("/")
def home():
    return "<h1>My learning notebook</h1>"

client = app.test_client()
response = client.get("/")
assert response.status_code == 200
assert b"learning notebook" in response.data
