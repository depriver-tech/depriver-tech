# Python for Web: Static files and caching
from flask import Flask, url_for
app = Flask(__name__)
with app.test_request_context():
    assert url_for("static", filename="site.css") == (
        "/static/site.css")
    assert url_for("static", filename="covers/python.webp") == (
        "/static/covers/python.webp")
