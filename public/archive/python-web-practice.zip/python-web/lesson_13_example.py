# Python for Web: Pagination and navigation
def page_items(values, page, size=3):
    if page < 1 or size < 1:
        raise ValueError("Positive page and size required")
    start = (page - 1) * size
    return values[start:start + size]

assert page_items(list(range(8)), 2) == [3, 4, 5]
assert page_items([], 1) == []
