# Python for Web: HTML with meaning
from flask import Flask
app = Flask(__name__)
@app.get("/")
def home():
    return """<!doctype html><html lang="en">
    <head><title>Reading list</title></head><body>
    <main><h1>Reading list</h1><ul>
    <li><a href="/git">Read the Git notebook</a></li>
    <li><a href="/python">Read the Python notebook</a></li>
    </ul></main></body></html>"""
html = app.test_client().get("/").text
assert html.count("<h1>") == 1
assert "<ul>" in html and 'lang="en"' in html
