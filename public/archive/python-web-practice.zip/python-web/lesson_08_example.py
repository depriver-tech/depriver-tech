# Python for Web: POST and validation
from flask import Flask, request, render_template_string
app = Flask(__name__)
@app.post("/check")
def check():
    title = request.form.get("title", "").strip()
    if not 2 <= len(title) <= 80:
        return "Title must contain 2-80 characters", 400
    return render_template_string("<p>{{ title }}</p>", title=title)
c = app.test_client()
assert c.post("/check", data={"title": "  "}).status_code == 400
assert c.post("/check", data={"title": "Git"}).status_code == 200
