# Python for Web: Search-friendly pages
SITE = "https://example.org"
pages = [
    {"path": "/", "title": "Learning library"},
    {"path": "/python", "title": "Python practical guide"},
]
for page in pages:
    page["canonical"] = SITE + page["path"]
assert len({p["title"] for p in pages}) == 2
assert all(p["canonical"].startswith(SITE) for p in pages)
