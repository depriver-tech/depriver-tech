# Python for Web: Small JavaScript enhancements
script = """const input = document.querySelector('#filter');
const cards = document.querySelectorAll('[data-title]');
input.addEventListener('input', () => {
  const query = input.value.trim().toLowerCase();
  for (const card of cards) {
    card.hidden = !card.dataset.title.includes(query);
  }
});"""
assert "card.hidden" in script
print(script)
