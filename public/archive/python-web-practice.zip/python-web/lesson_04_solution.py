# Python for Web: Templates and escaping
from flask import Flask, render_template_string
app = Flask(__name__)
T = """<ul>{% for name in names %}<li>{{ name }}</li>
{% else %}<li>No lessons yet</li>{% endfor %}</ul>"""
with app.app_context():
    html = render_template_string(T, names=["Git", "AI & ML"])
    assert html.count("<li>") == 2
    assert "AI &amp; ML" in html
    assert "No lessons yet" in render_template_string(T,
                                                      names=[])
