# Python for Web: CSS and responsive layout
from flask import Flask
app = Flask(__name__)
@app.get("/")
def home():
    return """<meta name="viewport" content="width=device-width">
    <style>main{max-width:60rem;margin:auto;padding:1rem}
    .grid{display:grid;gap:1rem;
    grid-template-columns:repeat(auto-fit,minmax(15rem,1fr))}
    a:focus-visible{outline:3px solid navy}</style>
    <main><h1>Books</h1><div class="grid">
    <article>Git</article><article>Python</article></div></main>"""
assert b"viewport" in app.test_client().get("/").data
