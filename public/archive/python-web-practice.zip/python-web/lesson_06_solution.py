# Python for Web: CSS and responsive layout
css = """
.article { max-width: 68ch; margin-inline: auto;
           padding: 1rem; line-height: 1.8; }
.article img { max-width: 100%; height: auto; }
.article pre { overflow-x: auto; padding: 1rem; }
.article a:focus-visible { outline: 3px solid #244e9a; }
"""
assert "68ch" in css
assert "overflow-x: auto" in css
print(css)
