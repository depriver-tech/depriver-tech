# Python for Web: Search-friendly pages
from html import escape

def metadata(title, description, canonical):
    return (f"<title>{escape(title)}</title>"
            f'<meta name="description" content="{escape(description)}">'
            f'<link rel="canonical" href="{escape(canonical)}">')
html = metadata("Python guide", "Learn by building.",
                "https://example.org/guides/python")
assert "canonical" in html
