# Python for Web: Cookies and sessions
def normalise_theme(value):
    return value if value in {"light", "dark"} else "light"

assert normalise_theme("dark") == "dark"
assert normalise_theme("light") == "light"
assert normalise_theme("<script>") == "light"
settings = {"theme": normalise_theme("dark")}
assert settings == {"theme": "dark"}
