# Python for Web: Routes and URL parameters
from flask import Flask, abort
app = Flask(__name__)
lessons = {1: "Variables", 2: "Functions"}
@app.get("/lessons/<int:ident>")
def detail(ident):
    if ident not in lessons:
        abort(404)
    return lessons[ident]
c = app.test_client()
assert c.get("/lessons/1").text == "Variables"
assert c.get("/lessons/99").status_code == 404
