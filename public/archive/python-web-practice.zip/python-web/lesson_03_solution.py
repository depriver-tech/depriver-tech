# Python for Web: Routes and URL parameters
from flask import Flask, abort
app = Flask(__name__)
cities = {"mbeya": "Mbeya", "arusha": "Arusha"}
@app.get("/cities/<slug>")
def city(slug):
    if slug not in cities:
        abort(404)
    return cities[slug]
c = app.test_client()
assert c.get("/cities/mbeya").text == "Mbeya"
assert c.get("/cities/unknown").status_code == 404
