# Python for Web: POST and validation
def validate(data):
    clean = {key: data.get(key, "").strip()
             for key in ["name", "message"]}
    errors = {}
    if not 2 <= len(clean["name"]) <= 80:
        errors["name"] = "Use 2-80 characters"
    if not 10 <= len(clean["message"]) <= 1000:
        errors["message"] = "Use 10-1000 characters"
    return clean, errors

assert "name" in validate({})[1]
assert not validate({"name": "Asha",
                     "message": "Please send the guide."})[1]
