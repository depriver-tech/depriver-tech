# Python for Web: Accessible interaction
html = """<form>
<label for="query">Search lessons</label>
<input id="query" name="q" aria-describedby="hint">
<p id="hint">Search by title or topic.</p>
<button type="submit">Find lessons</button>
</form>"""
assert 'for="query"' in html
assert 'id="query"' in html
assert 'aria-describedby="hint"' in html
