# Python for Web: Project: a learning library
from flask import Flask, request, render_template_string
app = Flask(__name__)
BOOKS = {1: "Python Web", 2: "Git Notebook"}
@app.get("/")
def home():
    q = request.args.get("q", "").casefold()
    rows = [(i, t) for i, t in BOOKS.items() if q in t.casefold()]
    return render_template_string("""<h1>Library</h1>
    {% for i,t in rows %}<p><a href="/books/{{ i }}">{{ t }}</a></p>
    {% else %}<p>No matching books</p>{% endfor %}""", rows=rows)
c = app.test_client()
assert "Python Web" in c.get("/?q=python").text
assert "Git Notebook" not in c.get("/?q=python").text
