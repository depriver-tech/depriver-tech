# Python for Web: HTML with meaning
from flask import Flask
app = Flask(__name__)
PAGE = """<!doctype html><html lang="en">
<head><title>Python notes</title></head>
<body><nav><a href="/">Home</a></nav><main>
<h1>Python notes</h1><p>One idea at a time.</p>
</main></body></html>"""
@app.get("/")
def home():
    return PAGE
assert b"<main>" in app.test_client().get("/").data
