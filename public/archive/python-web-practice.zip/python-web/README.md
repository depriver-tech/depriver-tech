# Python for Web - practice files

By Privatus Cosmas (Priver), depriver.tech. Companion to the 64-page notebook.

## Setup

Use Python 3.11 or newer. Create and activate a virtual environment, then install Flask. Save each example in its own file. Run it normally to execute the included checks. To view an example with an app variable in a browser, run python -m flask --app lesson_01_example run, then open the local URL. Keep the development server local.

```sh
python -m pip install Flask
python lesson_01_example.py
python -m flask --app lesson_01_example run
```

Create a virtual environment before installing third-party packages:

```sh
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
```

There are 20 example scripts and 20 matching solutions. Run each file on its own.
Most successful checks print nothing; a failed assertion produces a traceback.
Read the lesson before its solution. lesson.md provides the complete text.

These are local educational fixtures. No live service credentials are needed.
Tests establish the demonstrated examples, not production readiness. Browser,
network, deployment and security review remain separate work for a real app.

## Official references

- [Flask quickstart](https://flask.palletsprojects.com/en/stable/quickstart/)
- [Flask tutorial](https://flask.palletsprojects.com/en/stable/tutorial/)
- [Testing websites](https://flask.palletsprojects.com/en/stable/testing/)
- [Template documentation](https://jinja.palletsprojects.com/en/stable/templates/)
- [Security considerations](https://flask.palletsprojects.com/en/stable/web-security/)
- [Production deployment](https://flask.palletsprojects.com/en/stable/deploying/)
