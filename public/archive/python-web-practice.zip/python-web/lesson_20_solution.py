# Python for Web: Project: a learning library
from flask import Flask, abort, render_template_string
app = Flask(__name__)
BOOKS = {1: "Python Web", 2: "Git Notebook"}
@app.get("/")
def home():
    return "<h1>Library</h1>"
@app.get("/books/<int:ident>")
def detail(ident):
    if ident not in BOOKS:
        abort(404)
    return render_template_string("""<h1>{{ title }}</h1>
    <a href="/">Back to library</a>""", title=BOOKS[ident])
c = app.test_client()
assert "Python Web" in c.get("/books/1").text
assert "Back to library" in c.get("/books/1").text
assert c.get("/books/99").status_code == 404
