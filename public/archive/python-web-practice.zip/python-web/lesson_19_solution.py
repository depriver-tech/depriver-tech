# Python for Web: Testing and release checks
from flask import Flask

def create_app(label):
    app = Flask(__name__)
    @app.get("/")
    def home():
        return label
    return app

first = create_app("First")
second = create_app("Second")
assert first.test_client().get("/").text == "First"
assert second.test_client().get("/").text == "Second"
