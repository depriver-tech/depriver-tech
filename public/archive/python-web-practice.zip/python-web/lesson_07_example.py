# Python for Web: Forms and GET requests
from flask import Flask, request, render_template_string
app = Flask(__name__)
@app.get("/")
def search():
    query = request.args.get("q", "").strip()
    return render_template_string("""
    <form><label>Search <input name="q" value="{{ q }}"></label>
    <button>Search</button></form><p>Query: {{ q }}</p>""", q=query)
c = app.test_client()
assert "Python" in c.get("/?q=Python").text
