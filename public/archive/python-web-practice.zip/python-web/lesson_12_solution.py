# Python for Web: Database-backed pages
import sqlite3
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE books (title TEXT)")
con.execute("INSERT INTO books VALUES (?)", ("Priver's notes",))
def find(title):
    return con.execute("SELECT title FROM books WHERE title = ?",
                       (title,)).fetchone()
assert find("Priver's notes") == ("Priver's notes",)
assert find("missing") is None
con.close()
