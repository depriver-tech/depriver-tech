# Python for Web: Pagination and navigation
def paginate(values, page, size=3):
    if page < 1 or size < 1:
        raise ValueError("Invalid pagination")
    start = (page - 1) * size
    return {"items": values[start:start+size],
            "previous": page > 1,
            "next": page * size < len(values)}

assert paginate(list(range(8)), 1)["next"]
assert not paginate(list(range(8)), 3)["next"]
assert paginate([], 1) == {
    "items": [], "previous": False, "next": False}
