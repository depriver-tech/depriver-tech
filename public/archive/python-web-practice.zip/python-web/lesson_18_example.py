# Python for Web: Error pages that help
from flask import Flask
app = Flask(__name__)
@app.errorhandler(404)
def missing(error):
    return '<h1>Page not found</h1><a href="/">Go home</a>', 404
r = app.test_client().get("/absent")
assert r.status_code == 404
assert b"Go home" in r.data
