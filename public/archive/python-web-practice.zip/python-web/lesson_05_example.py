# Python for Web: Reusable page layouts
from flask import Flask, render_template
from jinja2 import DictLoader
app = Flask(__name__)
app.jinja_loader = DictLoader({
 "base.html": "<title>{% block title %}{% endblock %}</title>"
              "<main>{% block body %}{% endblock %}</main>",
 "home.html": "{% extends 'base.html' %}"
              "{% block title %}Library{% endblock %}"
              "{% block body %}<h1>Library</h1>{% endblock %}"
})
@app.get("/")
def home():
    return render_template("home.html")
assert "<title>Library</title>" in app.test_client().get("/").text
