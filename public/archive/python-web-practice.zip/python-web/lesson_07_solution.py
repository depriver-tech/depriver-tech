# Python for Web: Forms and GET requests
def search_titles(titles, query):
    query = query.strip().casefold()
    return [title for title in titles
            if query in title.casefold()]

titles = ["Python web", "Git", "Python AI"]
assert search_titles(titles, "PYTHON") == [
    "Python web", "Python AI"]
assert search_titles(titles, "missing") == []
assert search_titles(titles, "") == titles
