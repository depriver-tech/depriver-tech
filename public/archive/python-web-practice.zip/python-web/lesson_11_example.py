# Python for Web: Cookies and sessions
from flask import Flask, session
app = Flask(__name__)
app.config["SECRET_KEY"] = "local-demo-not-for-production"
@app.get("/")
def home():
    return session.get("theme", "light")
with app.test_client() as client:
    with client.session_transaction() as state:
        state["theme"] = "dark"
    assert client.get("/").text == "dark"
