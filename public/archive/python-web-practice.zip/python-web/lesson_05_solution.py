# Python for Web: Reusable page layouts
from flask import Flask, render_template
from jinja2 import DictLoader
app = Flask(__name__)
app.jinja_loader = DictLoader({
 "base": "{% block body %}{% endblock %}<footer>Priver</footer>",
 "a": "{% extends 'base' %}{% block body %}About{% endblock %}",
 "b": "{% extends 'base' %}{% block body %}Books{% endblock %}"
})
with app.app_context():
    for name in ["a", "b"]:
        assert "<footer>Priver</footer>" in render_template(name)
