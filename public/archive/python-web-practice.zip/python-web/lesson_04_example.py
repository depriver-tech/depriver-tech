# Python for Web: Templates and escaping
from flask import Flask, render_template_string
app = Flask(__name__)
@app.get("/")
def home():
    return render_template_string(
        "<h1>Hello, {{ name }}</h1>", name="<Asha>")
html = app.test_client().get("/").text
assert "&lt;Asha&gt;" in html
assert "<Asha>" not in html
