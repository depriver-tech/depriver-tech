# Python for Web: Error pages that help
from flask import Flask, abort
app = Flask(__name__)
@app.get("/invalid")
def invalid():
    return "Enter a valid page number", 400
@app.get("/missing")
def missing():
    abort(404)
c = app.test_client()
assert c.get("/invalid").status_code == 400
assert c.get("/missing").status_code == 404
assert "Traceback" not in c.get("/missing").text
