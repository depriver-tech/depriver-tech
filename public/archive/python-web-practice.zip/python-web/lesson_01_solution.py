# Python for Web: A request becomes a response
from flask import Flask
app = Flask(__name__)

@app.get("/")
def home():
    return "<h1>Learning library</h1>"

@app.get("/about")
def about():
    return "<h1>About</h1><p>I build useful software.</p>"

client = app.test_client()
assert client.get("/").status_code == 200
assert b"About" in client.get("/about").data
assert client.get("/missing").status_code == 404
