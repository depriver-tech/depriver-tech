# Python for Web: Small JavaScript enhancements
def search_label(title, tags):
    return " ".join((title + " " + " ".join(tags)).split()).casefold()

assert search_label(" Python  Web ", ["Flask"]) == (
    "python web flask")
assert search_label("Git", []) == "git"
