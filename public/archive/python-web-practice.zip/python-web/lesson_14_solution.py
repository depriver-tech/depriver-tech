# Python for Web: Accessible interaction
html = """<label for="title">Lesson title</label>
<input id="title" name="title" aria-invalid="true"
       aria-describedby="title-error">
<p id="title-error">Enter a title with 2-80 characters.</p>"""
assert 'aria-invalid="true"' in html
assert 'aria-describedby="title-error"' in html
assert 'id="title-error"' in html
