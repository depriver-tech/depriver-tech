# Python for AI & ML: Linear regression
import numpy as np
x = np.array([1.0, 2.0, 3.0])
y = np.array([7.0, 10.0, 13.0])
X = np.column_stack([np.ones(len(x)), x])
w, *_ = np.linalg.lstsq(X, y, rcond=None)
assert np.allclose(w, [4.0, 3.0])
assert np.isclose(np.array([1.0, 4.0]) @ w, 16.0)
assert np.allclose(y - X @ w, 0)
