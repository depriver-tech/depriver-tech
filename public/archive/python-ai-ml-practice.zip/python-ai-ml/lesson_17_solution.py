# Python for AI & ML: Text features and similarity
def jaccard(left, right):
    union = left | right
    return len(left & right) / len(union) if union else 1.0
assert jaccard({"python","web"}, {"python","data"}) == 1/3
assert jaccard({"a"}, {"a"}) == 1
assert jaccard({"a"}, {"b"}) == 0
assert jaccard(set(), set()) == 1
