# Python for AI & ML: Overfitting and model choice
experiments = [
    {"depth": 1, "train_error": 0.20, "valid_error": 0.22},
    {"depth": 3, "train_error": 0.10, "valid_error": 0.15},
    {"depth": 9, "train_error": 0.00, "valid_error": 0.30},
]
best = min(experiments, key=lambda row: row["valid_error"])
assert best["depth"] == 3
