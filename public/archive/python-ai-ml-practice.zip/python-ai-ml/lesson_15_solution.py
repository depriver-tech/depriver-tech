# Python for AI & ML: Cross-validation and leakage
all_ids = set(range(9))
folds = [set(range(i, 9, 3)) for i in range(3)]
for valid in folds:
    train = all_ids - valid
    assert train.isdisjoint(valid)
    assert train | valid == all_ids
assert set.union(*folds) == all_ids
assert sum(len(f) for f in folds) == len(all_ids)
