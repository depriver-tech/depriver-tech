# Python for AI & ML: Cross-validation and leakage
def folds(n, k):
    if not 2 <= k <= n:
        raise ValueError("Invalid fold count")
    return [list(range(i, n, k)) for i in range(k)]
parts = folds(9, 3)
assert sorted(x for part in parts for x in part) == list(range(9))
assert all(len(part) == 3 for part in parts)
