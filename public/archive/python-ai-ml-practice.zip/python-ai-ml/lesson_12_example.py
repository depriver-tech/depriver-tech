# Python for AI & ML: Probabilities and thresholds
from math import exp

def sigmoid(value):
    if value >= 0:
        return 1 / (1 + exp(-value))
    z = exp(value)
    return z / (1 + z)
assert sigmoid(0) == 0.5
assert 0 < sigmoid(-10) < sigmoid(10) < 1
