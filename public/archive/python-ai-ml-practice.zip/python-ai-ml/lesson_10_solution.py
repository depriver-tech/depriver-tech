# Python for AI & ML: Loss and gradient descent
def optimise(start, rate=0.1, steps=100):
    weight = start
    for _ in range(steps):
        weight -= rate * 2 * (weight - 3)
    return weight
assert abs(optimise(-5) - 3) < 1e-6
assert abs(optimise(10) - 3) < 1e-6
assert abs(optimise(-5, steps=0) + 5) < 1e-9
