# Python for AI & ML: Arrays and shapes
import numpy as np

def predict(X, weights, bias):
    X = np.asarray(X, dtype=float)
    weights = np.asarray(weights, dtype=float)
    if X.ndim != 2 or X.shape[1] != len(weights):
        raise ValueError("Wrong feature shape")
    return X @ weights + bias
assert np.allclose(predict([[1, 2], [3, 4]], [2, 1], 3), [7, 13])
try:
    predict([[1, 2, 3]], [2, 1], 3)
except ValueError:
    pass
else:
    raise AssertionError("Shape mismatch accepted")
