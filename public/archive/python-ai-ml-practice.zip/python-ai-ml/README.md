# Python for AI & ML - practice files

By Privatus Cosmas (Priver), depriver.tech. Companion to the 64-page notebook.

## Setup

Use Python 3.11 or newer and a virtual environment. Install NumPy for numerical examples. Most examples also work with the standard library alone. Every dataset is included in the code, so no dataset download or paid AI API is needed. Save each example separately and run it before changing one assumption.

```sh
python -m pip install numpy
python lesson_01_example.py
python lesson_01_solution.py
```

Create a virtual environment before installing third-party packages:

```sh
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
```

There are 20 example scripts and 20 matching solutions. Run each file on its own.
Most successful checks print nothing; a failed assertion produces a traceback.
Read the lesson before its solution. lesson.md provides the complete text.

These are local educational fixtures. No live service credentials are needed.
Tests establish the demonstrated examples, not production readiness. Browser,
network, deployment and security review remain separate work for a real app.

## Official references

- [NumPy learning resources](https://numpy.org/learn/)
- [scikit-learn getting started](https://scikit-learn.org/stable/getting_started.html)
- [Avoiding leakage](https://scikit-learn.org/stable/common_pitfalls.html)
- [Model evaluation](https://scikit-learn.org/stable/modules/model_evaluation.html)
- [Text feature extraction](https://scikit-learn.org/stable/modules/feature_extraction.html#text-feature-extraction)
- [Model persistence](https://scikit-learn.org/stable/model_persistence.html)
