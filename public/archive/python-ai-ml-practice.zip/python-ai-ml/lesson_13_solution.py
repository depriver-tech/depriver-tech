# Python for AI & ML: Metrics that match mistakes
def metrics(tp, fp, fn):
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2*precision*recall/(precision+recall) if precision+recall else 0.0
    return precision, recall, f1
assert metrics(1, 1, 1) == (0.5, 0.5, 0.5)
assert metrics(0, 0, 0) == (0.0, 0.0, 0.0)
assert metrics(3, 0, 0) == (1.0, 1.0, 1.0)
