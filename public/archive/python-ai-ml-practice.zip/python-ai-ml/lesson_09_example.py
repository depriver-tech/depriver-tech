# Python for AI & ML: Linear regression
import numpy as np
x = np.array([1.0, 2.0, 3.0, 4.0])
y = np.array([3.0, 5.0, 7.0, 9.0])
X = np.column_stack([np.ones(len(x)), x])
weights, *_ = np.linalg.lstsq(X, y, rcond=None)
assert np.allclose(weights, [1.0, 2.0])
assert np.isclose(np.array([1.0, 5.0]) @ weights, 11.0)
