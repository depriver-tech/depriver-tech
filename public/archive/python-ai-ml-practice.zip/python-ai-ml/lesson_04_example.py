# Python for AI & ML: Inspect before training
rows = [{"age": 20}, {"age": None}, {"age": -2}, {"age": 25}]
missing = sum(r["age"] is None for r in rows)
invalid = [r for r in rows if r["age"] is not None and r["age"] < 0]
assert missing == 1
assert invalid == [{"age": -2}]
