# Python for AI & ML: Clustering without labels
import numpy as np
points = np.array([0.0, 1.0, 9.0, 10.0])
centres = np.array([0.0, 10.0])
for _ in range(5):
    labels = np.abs(points[:, None] - centres).argmin(axis=1)
    for i in range(len(centres)):
        members = points[labels == i]
        if len(members):
            centres[i] = members.mean()
assert np.allclose(sorted(centres), [0.5, 9.5])
assert np.isfinite(centres).all()
