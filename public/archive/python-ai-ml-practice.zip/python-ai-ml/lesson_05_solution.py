# Python for AI & ML: Train, validation and test
rows = [("A", 1), ("A", 2), ("B", 3), ("C", 4), ("C", 5)]
held_out = {"C"}
train = [r for r in rows if r[0] not in held_out]
test = [r for r in rows if r[0] in held_out]
assert {r[0] for r in train}.isdisjoint(r[0] for r in test)
assert len(train) == 3 and len(test) == 2
