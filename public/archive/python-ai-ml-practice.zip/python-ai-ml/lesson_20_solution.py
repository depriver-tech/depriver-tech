# Python for AI & ML: Project: an honest experiment
import numpy as np

def experiment(x_train, y_train, x_test, y_test):
    x_train, y_train = map(np.asarray, (x_train, y_train))
    x_test, y_test = map(np.asarray, (x_test, y_test))
    if len(x_train) != len(y_train) or len(x_test) != len(y_test):
        raise ValueError("Mismatched rows")
    X = np.column_stack([np.ones(len(x_train)), x_train])
    w, *_ = np.linalg.lstsq(X, y_train, rcond=None)
    T = np.column_stack([np.ones(len(x_test)), x_test])
    return {"weights": w.tolist(),
            "model_mae": float(np.abs(y_test-T@w).mean()),
            "baseline_mae": float(np.abs(y_test-y_train.mean()).mean())}
r = experiment([1,2,3,4], [3,5,7,9], [5,6], [11,13])
assert r["model_mae"] < 1e-10
assert r["baseline_mae"] > r["model_mae"]
assert np.allclose(r["weights"], [1, 2])
