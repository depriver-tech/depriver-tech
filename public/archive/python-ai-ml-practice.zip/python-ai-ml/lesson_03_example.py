# Python for AI & ML: Arrays and shapes
import numpy as np
X = np.array([[1.0, 2.0], [3.0, 4.0]])
w = np.array([2.0, 1.0])
predictions = X @ w
assert X.shape == (2, 2)
assert predictions.shape == (2,)
assert np.allclose(predictions, [4.0, 10.0])
