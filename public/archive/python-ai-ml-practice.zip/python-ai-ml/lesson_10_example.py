# Python for AI & ML: Loss and gradient descent
weight = 0.0
rate = 0.1
losses = []
for _ in range(30):
    loss = (weight - 3.0) ** 2
    losses.append(loss)
    gradient = 2 * (weight - 3.0)
    weight -= rate * gradient
assert losses[-1] < losses[0]
assert abs(weight - 3.0) < 0.01
