# Python for AI & ML: Inspect before training
def quality(values):
    valid = [v for v in values if v is not None]
    return {"total": len(values), "missing": len(values)-len(valid),
            "valid": len(valid), "min": min(valid) if valid else None,
            "max": max(valid) if valid else None}
assert quality([1, None, 3])["missing"] == 1
assert quality([None])["min"] is None
assert quality([])["total"] == 0
