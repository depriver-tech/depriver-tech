# Python for AI & ML: Text features and similarity
from collections import Counter

def bag(text):
    return Counter(text.casefold().split())
a = bag("python web python")
b = bag("python data")
assert a["python"] == 2
assert set(a) & set(b) == {"python"}
