# Python for AI & ML: Rows, features and targets
row = {"distance_km": 12, "dispatch_hour": 9,
       "arrival_hour": 11, "late": True}
feature_names = ["distance_km", "dispatch_hour"]
features = [row[name] for name in feature_names]
target = row["late"]
assert features == [12, 9]
assert target is True
assert "arrival_hour" not in feature_names
