# Python for AI & ML: Nearest-neighbour classification
from collections import Counter

def classify(points, query, k):
    if not 1 <= k <= len(points):
        raise ValueError("Invalid k")
    near = sorted(points, key=lambda p: abs(p[0]-query))[:k]
    counts = Counter(label for _, label in near)
    return min(counts, key=lambda label: (-counts[label], label))
assert classify([(1,"A"),(2,"A"),(3,"B")], 2, 3) == "A"
assert classify([(1,"B"),(3,"A")], 2, 2) == "A"
