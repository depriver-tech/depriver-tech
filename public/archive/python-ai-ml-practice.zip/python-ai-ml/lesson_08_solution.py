# Python for AI & ML: Scaling and feature units
import numpy as np
train = np.array([5.0, 5.0, 5.0])
mean = train.mean()
scale = train.std()
if scale == 0:
    scale = 1.0
assert np.allclose((train - mean) / scale, 0)
assert (7.0 - mean) / scale == 2.0
