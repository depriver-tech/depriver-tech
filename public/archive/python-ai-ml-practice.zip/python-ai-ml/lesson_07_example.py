# Python for AI & ML: Missing-value strategies
train = [2.0, None, 6.0]
known = [x for x in train if x is not None]
fill = sum(known) / len(known)
clean = [fill if x is None else x for x in train]
assert clean == [2.0, 4.0, 6.0]
