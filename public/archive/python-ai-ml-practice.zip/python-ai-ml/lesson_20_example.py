# Python for AI & ML: Project: an honest experiment
import numpy as np
x_train = np.array([1., 2., 3., 4.])
y_train = np.array([3., 5., 7., 9.])
x_test = np.array([5., 6.])
y_test = np.array([11., 13.])
X = np.column_stack([np.ones(len(x_train)), x_train])
w, *_ = np.linalg.lstsq(X, y_train, rcond=None)
pred = np.column_stack([np.ones(len(x_test)), x_test]) @ w
mae = np.abs(y_test - pred).mean()
baseline = np.abs(y_test - y_train.mean()).mean()
assert mae < 1e-10
assert baseline > mae
