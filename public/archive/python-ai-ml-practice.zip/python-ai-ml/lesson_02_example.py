# Python for AI & ML: Rows, features and targets
rows = [
    {"hours": 1, "practice": 2, "score": 45},
    {"hours": 3, "practice": 5, "score": 70},
    {"hours": 5, "practice": 8, "score": 90},
]
X = [[r["hours"], r["practice"]] for r in rows]
y = [r["score"] for r in rows]
assert len(X) == len(y) == 3
assert X[0] == [1, 2]
