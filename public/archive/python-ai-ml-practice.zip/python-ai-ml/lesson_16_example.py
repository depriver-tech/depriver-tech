# Python for AI & ML: Clustering without labels
import numpy as np
points = np.array([0.0, 1.0, 9.0, 10.0])
centres = np.array([0.0, 10.0])
labels = np.abs(points[:, None] - centres).argmin(axis=1)
updated = np.array([points[labels == i].mean() for i in range(2)])
assert np.allclose(updated, [0.5, 9.5])
