# Python for AI & ML: Baselines before models
def mean_baseline(train, test):
    if not train or not test:
        raise ValueError("Non-empty train and test required")
    prediction = sum(train) / len(train)
    mae = sum(abs(y - prediction) for y in test) / len(test)
    return prediction, mae
assert mean_baseline([2, 4, 6], [3, 5]) == (4.0, 1.0)
