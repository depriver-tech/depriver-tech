# Python for AI & ML: Model cards and monitoring
card = {"purpose": "Suggest support categories",
        "data": "Fictional teaching messages",
        "limitations": ["Tiny sample", "English only"],
        "human_review": True,
        "version": "demo-1"}
assert card["limitations"]
assert card["human_review"] is True
