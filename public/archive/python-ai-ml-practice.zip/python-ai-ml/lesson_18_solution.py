# Python for AI & ML: Retrieval before generation
def evidence(query, docs):
    words = set(query.casefold().split())
    ranked = sorted(docs, key=lambda k:
                    (-len(words & set(docs[k].split())), k))
    if not ranked or not words.intersection(docs[ranked[0]].split()):
        return {"evidence_found": False}
    ident = ranked[0]
    return {"evidence_found": True, "source": ident,
            "passage": docs[ident]}
docs = {"a": "python flask routes"}
assert evidence("flask", docs)["passage"] == docs["a"]
assert evidence("ocean", docs) == {"evidence_found": False}
