# Python for AI & ML: Baselines before models
from collections import Counter
labels = ["A", "A", "B", "A"]
majority = Counter(labels).most_common(1)[0][0]
predictions = [majority] * 3
assert predictions == ["A", "A", "A"]
