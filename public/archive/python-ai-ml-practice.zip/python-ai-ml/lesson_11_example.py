# Python for AI & ML: Nearest-neighbour classification
def nearest_label(points, query):
    if not points:
        raise ValueError("Training examples required")
    return min(points, key=lambda p: abs(p[0]-query))[1]
points = [(1.0, "low"), (5.0, "high"), (8.0, "high")]
assert nearest_label(points, 2.0) == "low"
assert nearest_label(points, 7.0) == "high"
