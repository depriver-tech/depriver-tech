# Python for AI & ML: Probabilities and thresholds
def decisions(scores, threshold):
    if not 0 <= threshold <= 1:
        raise ValueError("Threshold outside [0,1]")
    return [int(score >= threshold) for score in scores]
scores = [0.2, 0.6, 0.9]
a, b = decisions(scores, 0.5), decisions(scores, 0.8)
assert a == [0, 1, 1] and b == [0, 0, 1]
assert sum(x != y for x, y in zip(a, b)) == 1
