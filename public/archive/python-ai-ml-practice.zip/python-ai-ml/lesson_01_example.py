# Python for AI & ML: Define the problem first
problem = {
    "input": "support message text",
    "target": "billing or technical",
    "action": "suggest a queue for human review",
    "metric": "macro F1 plus per-class error review",
}
assert problem["target"]
assert "human" in problem["action"]
