# Python for AI & ML: Overfitting and model choice
def choose(models, tolerance=0.01):
    best = min(m["error"] for m in models)
    eligible = [m for m in models if m["error"] <= best+tolerance]
    return min(eligible, key=lambda m: m["complexity"])
models = [{"name":"simple","error":0.151,"complexity":1},
          {"name":"large","error":0.15,"complexity":10}]
assert choose(models)["name"] == "simple"
