# Python for AI & ML: Metrics that match mistakes
truth = [1, 1, 0, 0]
pred = [1, 0, 1, 0]
tp = sum(a == b == 1 for a, b in zip(truth, pred))
fp = sum(a == 0 and b == 1 for a, b in zip(truth, pred))
fn = sum(a == 1 and b == 0 for a, b in zip(truth, pred))
assert (tp, fp, fn) == (1, 1, 1)
