# Python for AI & ML: Missing-value strategies
def fit_fill(values):
    known = [v for v in values if v is not None]
    if not known:
        raise ValueError("No observed training values")
    return sum(known) / len(known)
def transform(values, fill):
    return ([fill if v is None else v for v in values],
            [int(v is None) for v in values])
fill = fit_fill([2, None, 6])
assert transform([None, 10], fill) == ([4.0, 10], [1, 0])
