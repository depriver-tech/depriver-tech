# Python for AI & ML: Model cards and monitoring
def missing_rate(values):
    if not values:
        raise ValueError("Empty batch")
    return sum(v is None for v in values) / len(values)
old = [None] + [1] * 9
new = [None] * 4 + [1] * 6
assert missing_rate(new) - missing_rate(old) > 0.2
assert missing_rate(old) - missing_rate(old) == 0
