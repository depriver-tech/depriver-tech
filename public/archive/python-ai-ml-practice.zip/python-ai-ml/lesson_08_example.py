# Python for AI & ML: Scaling and feature units
import numpy as np
X = np.array([[1.0, 10.0], [3.0, 30.0], [5.0, 50.0]])
mean = X.mean(axis=0)
scale = X.std(axis=0)
scale = np.where(scale == 0, 1.0, scale)
Z = (X - mean) / scale
assert np.allclose(Z.mean(axis=0), [0, 0])
