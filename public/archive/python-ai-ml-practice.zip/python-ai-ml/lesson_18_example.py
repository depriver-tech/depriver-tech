# Python for AI & ML: Retrieval before generation
documents = {"git": "git branches commits history",
             "web": "python flask routes templates",
             "data": "python arrays statistics"}
def retrieve(query):
    words = set(query.casefold().split())
    scores = [(len(words & set(text.split())), ident)
              for ident, text in documents.items()]
    score, ident = max(scores)
    return ident if score > 0 else None
assert retrieve("flask routes") == "web"
assert retrieve("ocean") is None
