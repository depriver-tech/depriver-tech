# Python for AI & ML: Define the problem first
tasks = {
    "delivery_minutes": "regression",
    "spam_label": "classification",
    "product_groups": "clustering",
}
assert tasks["delivery_minutes"] == "regression"
assert tasks["spam_label"] == "classification"
assert tasks["product_groups"] == "clustering"
