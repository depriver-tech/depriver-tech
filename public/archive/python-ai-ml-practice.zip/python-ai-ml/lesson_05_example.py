# Python for AI & ML: Train, validation and test
rows = list(range(10))
train = rows[:6]
validation = rows[6:8]
test = rows[8:]
assert set(train).isdisjoint(validation)
assert set(train).isdisjoint(test)
assert max(train) < min(test)
