# Python for Automation: HTTP integrations and fixtures
import json

def parse_items(payload):
    data = json.loads(payload)
    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        raise ValueError("Unexpected response shape")
    return data["items"]
assert parse_items('{"items": [{"id": 1}]}') == [{"id": 1}]
