# Python for Automation: Paths and working directories
from pathlib import Path
from tempfile import TemporaryDirectory
with TemporaryDirectory() as folder:
    root = Path(folder)
    output = root / "output"
    output.mkdir(parents=True, exist_ok=True)
    report = output / "report.txt"
    report.write_text("Ready", encoding="utf-8")
    assert report.parent == output
    assert report.read_text(encoding="utf-8") == "Ready"
