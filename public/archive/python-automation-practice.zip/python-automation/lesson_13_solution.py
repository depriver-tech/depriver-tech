# Python for Automation: HTTP integrations and fixtures
def validate_items(items):
    clean = []
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("Item must be an object")
        if type(item.get("id")) is not int:
            raise ValueError("Integer id required")
        if not isinstance(item.get("title"), str):
            raise ValueError("Title required")
        clean.append({"id": item["id"], "title": item["title"]})
    return clean
assert validate_items([{"id":1,"title":"Git"}]) == [
    {"id":1,"title":"Git"}]
