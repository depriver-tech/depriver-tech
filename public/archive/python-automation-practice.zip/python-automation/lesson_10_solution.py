# Python for Automation: Backups and restore checks
from hashlib import sha256
from io import BytesIO
from zipfile import ZipFile
payload = b"Notebook content"
expected = sha256(payload).hexdigest()
buffer = BytesIO()
with ZipFile(buffer, "w") as archive:
    archive.writestr("notes.txt", payload)
buffer.seek(0)
with ZipFile(buffer) as archive:
    restored = archive.read("notes.txt")
assert sha256(restored).hexdigest() == expected
assert sha256(payload+b"!").hexdigest() != expected
