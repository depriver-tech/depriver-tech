# Python for Automation: Choose the right task
def include_name(name):
    return not name.startswith(".") and name.lower().endswith(".txt")
assert include_name("notes.txt")
assert include_name("NOTES.TXT")
assert not include_name(".secret.txt")
assert not include_name("photo.jpg")
