# Python for Automation: Backups and restore checks
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
with TemporaryDirectory() as folder:
    root = Path(folder)
    source = root/"notes.txt"
    source.write_text("Important notes", encoding="utf-8")
    with ZipFile(root/"backup.zip", "w") as archive:
        archive.write(source, arcname="notes.txt")
    with ZipFile(root/"backup.zip") as archive:
        assert archive.read("notes.txt") == source.read_bytes()
