# Python for Automation: Scheduling and repeatability
def pending_jobs(all_ids, completed):
    return [ident for ident in all_ids if ident not in completed]
assert pending_jobs(["a","b","c"], {"a","c"}) == ["b"]
