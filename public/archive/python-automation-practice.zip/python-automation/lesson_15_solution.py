# Python for Automation: Subprocesses safely
import subprocess, sys
value = "hello; this is data"
r = subprocess.run([sys.executable, "-c",
                    "import sys; print(sys.argv[1])", value],
                   capture_output=True, text=True,
                   timeout=5, check=True)
assert r.stdout.strip() == value
assert r.returncode == 0
