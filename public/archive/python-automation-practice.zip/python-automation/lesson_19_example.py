# Python for Automation: Testing failure paths
def convert(value):
    number = int(value)
    if number < 0:
        raise ValueError("Negative count")
    return number
assert convert("12") == 12
for bad in ["text", "-1"]:
    try:
        convert(bad)
    except ValueError:
        pass
    else:
        raise AssertionError("Invalid input accepted")
