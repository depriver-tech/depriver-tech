# Python for Automation: Atomic output files
from pathlib import Path
from tempfile import TemporaryDirectory
import os
with TemporaryDirectory() as folder:
    target = Path(folder) / "report.txt"
    temporary = target.with_suffix(".tmp")
    temporary.write_text("complete report", encoding="utf-8")
    os.replace(temporary, target)
    assert target.read_text(encoding="utf-8") == "complete report"
