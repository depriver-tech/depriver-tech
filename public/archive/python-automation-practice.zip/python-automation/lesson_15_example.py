# Python for Automation: Subprocesses safely
import subprocess, sys
result = subprocess.run([sys.executable, "-c", "print(2 + 3)"],
                        capture_output=True, text=True,
                        timeout=5, check=True)
assert result.stdout.strip() == "5"
