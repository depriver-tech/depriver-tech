# Python for Automation: Email and notification previews
from email.message import EmailMessage
message = EmailMessage()
message["Subject"] = "Inventory complete"
message["From"] = "reports@example.test"
message["To"] = "owner@example.test"
message.set_content("Processed 12 files. No failures.")
assert "Processed 12 files" in message.get_content()
assert message["Subject"] == "Inventory complete"
