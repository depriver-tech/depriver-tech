# Python for Automation: CSV reports
import csv, io
source = "category,amount\nfood,3000\ntravel,1500\n"
rows = list(csv.DictReader(io.StringIO(source)))
total = sum(int(row["amount"]) for row in rows)
assert total == 4500
