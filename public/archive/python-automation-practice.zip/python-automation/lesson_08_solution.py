# Python for Automation: Plan before applying
def validate_plan(plan, existing):
    destinations = [dst for _, dst in plan]
    if len(destinations) != len(set(destinations)):
        raise ValueError("Duplicate destination")
    if any(dst in existing for dst in destinations):
        raise ValueError("Destination already exists")
    return True
assert validate_plan([("a b", "a_b")], {"a b"})
for plan, existing in [([("a","x"),("b","x")], set()),
                       ([("a","x")], {"x"})]:
    try:
        validate_plan(plan, existing)
    except ValueError:
        pass
    else:
        raise AssertionError("Conflict accepted")
