# Python for Automation: Email and notification previews
def should_notify(summary):
    if any(type(v) is not int or v < 0 for v in summary.values()):
        raise ValueError("Invalid counts")
    return summary.get("failed", 0) > 0
assert not should_notify({"success": 10, "failed": 0})
assert should_notify({"success": 8, "failed": 2})
