# Python for Automation: Logs and useful summaries
def summarise(results):
    counts = {"success": 0, "skipped": 0, "failed": 0}
    for status in results:
        if status not in counts:
            raise ValueError("Unknown status")
        counts[status] += 1
    return counts
assert summarise(["success","failed","success"]) == {
    "success": 2, "skipped": 0, "failed": 1}
assert sum(summarise([]).values()) == 0
