# Python for Automation: Inventory before changing files
from pathlib import Path
from tempfile import TemporaryDirectory

def inventory(root, minimum):
    return [(p.name, p.stat().st_size) for p in sorted(root.iterdir())
            if not p.is_symlink() and p.is_file()
            and p.stat().st_size >= minimum]
with TemporaryDirectory() as folder:
    root = Path(folder)
    (root/"small").write_bytes(b"hi")
    (root/"large").write_bytes(b"hello")
    (root/"subdir").mkdir()
    assert inventory(root, 3) == [("large", 5)]
