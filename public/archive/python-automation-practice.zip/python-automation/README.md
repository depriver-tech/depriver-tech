# Python for Automation - practice files

By Privatus Cosmas (Priver), depriver.tech. Companion to the 64-page notebook.

## Setup

Use Python 3.11 or newer. Create a separate practice folder and run one example at a time. Most filesystem exercises create TemporaryDirectory fixtures that are removed automatically. Copy a script into real use only after replacing sample paths deliberately, reviewing its preview and testing recovery.

```sh
python --version
python lesson_01_example.py
python lesson_01_solution.py
```

Create a virtual environment before installing third-party packages:

```sh
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
```

There are 20 example scripts and 20 matching solutions. Run each file on its own.
Most successful checks print nothing; a failed assertion produces a traceback.
Read the lesson before its solution. lesson.md provides the complete text.

These are local educational fixtures. No live service credentials are needed.
Tests establish the demonstrated examples, not production readiness. Browser,
network, deployment and security review remain separate work for a real app.

## Official references

- [Paths and files](https://docs.python.org/3/library/pathlib.html)
- [CSV processing](https://docs.python.org/3/library/csv.html)
- [File operations](https://docs.python.org/3/library/shutil.html)
- [Command-line arguments](https://docs.python.org/3/library/argparse.html)
- [Subprocesses](https://docs.python.org/3/library/subprocess.html)
- [Logging](https://docs.python.org/3/library/logging.html)
- [ZIP files](https://docs.python.org/3/library/zipfile.html)
