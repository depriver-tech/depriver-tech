# Python for Automation: Retries and backoff
def delays(attempts, base=1, cap=8):
    return [min(cap, base * 2**i) for i in range(attempts)]
assert delays(5) == [1, 2, 4, 8, 8]
