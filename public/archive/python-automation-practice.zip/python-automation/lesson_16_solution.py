# Python for Automation: Scheduling and repeatability
def process(ids, completed, operation):
    for ident in ids:
        if ident in completed:
            continue
        operation(ident)
        completed.add(ident)
completed, calls = set(), []
process(["a","a","b"], completed, calls.append)
assert calls == ["a","b"]
process(["a","b"], completed, calls.append)
assert calls == ["a","b"]
