# Python for Automation: Inventory before changing files
from pathlib import Path
from tempfile import TemporaryDirectory
with TemporaryDirectory() as folder:
    root = Path(folder)
    (root / "b.txt").write_bytes(b"hello")
    (root / "a.txt").write_bytes(b"hi")
    rows = [(p.name, p.stat().st_size)
            for p in sorted(root.glob("*.txt")) if p.is_file()]
    assert rows == [("a.txt", 2), ("b.txt", 5)]
