# Python for Automation: Browser automation choices
steps = [
    {"action": "open", "target": "local test page"},
    {"action": "fill", "target": "label: Search", "value": "Python"},
    {"action": "click", "target": "button: Search"},
    {"action": "expect", "target": "results contain Python"},
]
assert steps[-1]["action"] == "expect"
