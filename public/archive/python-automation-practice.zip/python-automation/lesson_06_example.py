# Python for Automation: JSON configuration
import json
config = json.loads('{"minimum_bytes": 10, "recursive": false}')
assert isinstance(config["minimum_bytes"], int)
assert config["recursive"] is False
