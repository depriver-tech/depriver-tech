# Python for Automation: Command-line interfaces
import argparse
parser = argparse.ArgumentParser(description="Preview an inventory")
parser.add_argument("folder")
parser.add_argument("--minimum", type=int, default=0)
args = parser.parse_args(["sample", "--minimum", "10"])
assert args.folder == "sample" and args.minimum == 10
