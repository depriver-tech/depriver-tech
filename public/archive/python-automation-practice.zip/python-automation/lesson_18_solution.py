# Python for Automation: Browser automation choices
def choose_interface(has_api, has_supported_ui):
    if has_api:
        return "api"
    if has_supported_ui:
        return "browser"
    raise ValueError("No supported interface")
assert choose_interface(True, True) == "api"
assert choose_interface(False, True) == "browser"
try:
    choose_interface(False, False)
except ValueError:
    pass
else:
    raise AssertionError("Unsupported workflow accepted")
