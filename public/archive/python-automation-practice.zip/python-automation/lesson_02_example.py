# Python for Automation: Paths and working directories
from pathlib import Path
from tempfile import TemporaryDirectory
with TemporaryDirectory() as folder:
    root = Path(folder)
    path = root / "notes.txt"
    path.write_text("Learn automation", encoding="utf-8")
    assert path.name == "notes.txt"
    assert path.suffix == ".txt"
    assert path.read_text(encoding="utf-8") == "Learn automation"
