# Python for Automation: Duplicates and hashes
from hashlib import sha256

def duplicate_groups(files):
    groups = {}
    for name, payload in files.items():
        key = sha256(payload).hexdigest()
        groups.setdefault(key, []).append(name)
    return [sorted(names) for names in groups.values() if len(names)>1]
assert duplicate_groups({"a":b"x", "b":b"x", "c":b"y"}) == [
    ["a", "b"]]
assert duplicate_groups({"a":b"x"}) == []
