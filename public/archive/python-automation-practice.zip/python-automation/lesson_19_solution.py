# Python for Automation: Testing failure paths
from pathlib import Path
from tempfile import TemporaryDirectory

def report(values, target):
    parsed = [int(value) for value in values]
    if any(value < 0 for value in parsed):
        raise ValueError("Negative count")
    target.write_text(str(sum(parsed)), encoding="utf-8")
with TemporaryDirectory() as folder:
    target = Path(folder)/"report.txt"
    try:
        report(["2", "bad"], target)
    except ValueError:
        pass
    assert not target.exists()
    report(["2", "3"], target)
    assert target.read_text() == "5"
