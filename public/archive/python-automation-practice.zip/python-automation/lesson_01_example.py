# Python for Automation: Choose the right task
workflow = {"input": "folder of text files",
            "rule": "list name and byte size",
            "output": "CSV inventory",
            "success": "one row per regular text file"}
assert workflow["input"] and workflow["success"]
