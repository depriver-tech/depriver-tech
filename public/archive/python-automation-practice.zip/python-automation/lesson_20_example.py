# Python for Automation: Project: a folder reporter
from pathlib import Path
from tempfile import TemporaryDirectory
import csv

def inventory(root):
    return [{"name": p.name, "bytes": p.stat().st_size}
            for p in sorted(root.iterdir())
            if not p.is_symlink() and p.is_file()]
def write_csv(rows, target):
    with target.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["name", "bytes"])
        writer.writeheader()
        writer.writerows(rows)
with TemporaryDirectory() as folder:
    root = Path(folder)/"input"
    root.mkdir()
    (root/"a.txt").write_bytes(b"abc")
    output = Path(folder)/"inventory.csv"
    write_csv(inventory(root), output)
    assert "a.txt,3" in output.read_text()
