# Python for Automation: Command-line interfaces
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("folder")
parser.add_argument("--apply", action="store_true",
                    help="Apply the reviewed plan")
assert not parser.parse_args(["sample"]).apply
assert parser.parse_args(["sample", "--apply"]).apply
assert "--apply" in parser.format_help()
