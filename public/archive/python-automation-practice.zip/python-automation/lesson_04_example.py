# Python for Automation: Text cleanup
def clean_lines(text):
    return [line.strip() for line in text.splitlines() if line.strip()]
assert clean_lines(" Asha \n\n Juma\n") == ["Asha", "Juma"]
