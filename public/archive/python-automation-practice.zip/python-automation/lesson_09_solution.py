# Python for Automation: Atomic output files
from pathlib import Path
from tempfile import TemporaryDirectory, NamedTemporaryFile
import os

def write_report(target, text):
    with NamedTemporaryFile("w", encoding="utf-8", delete=False,
                            dir=target.parent) as handle:
        temporary = Path(handle.name)
        handle.write(text)
    try:
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
with TemporaryDirectory() as folder:
    target = Path(folder)/"report.txt"
    write_report(target, "ready")
    assert target.read_text() == "ready"
