# Python for Automation: Plan before applying
def rename_plan(names):
    return [(name, name.replace(" ", "_")) for name in names
            if " " in name]
assert rename_plan(["my notes.txt", "plain.txt"]) == [
    ("my notes.txt", "my_notes.txt")]
