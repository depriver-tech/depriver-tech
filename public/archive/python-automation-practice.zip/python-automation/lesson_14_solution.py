# Python for Automation: Retries and backoff
def retry(operation, sleep, attempts=3):
    for i in range(attempts):
        try:
            return operation()
        except TimeoutError:
            if i == attempts - 1:
                raise
            sleep(min(8, 2**i))
    raise ValueError("Positive attempts required")
calls, pauses = [], []
def operation():
    calls.append(1)
    if len(calls) < 3:
        raise TimeoutError()
    return "done"
assert retry(operation, pauses.append) == "done"
assert pauses == [1, 2]
