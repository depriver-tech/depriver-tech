# Python for Automation: Text cleanup
def unique_ids(values):
    seen, result = set(), []
    for value in values:
        clean = value.strip().casefold()
        if clean and clean not in seen:
            seen.add(clean)
            result.append(clean)
    return result
assert unique_ids([" A@EXAMPLE.TEST ", "a@example.test", "B@x.test"])
assert unique_ids([" A@EXAMPLE.TEST ", "a@example.test"]) == [
    "a@example.test"]
