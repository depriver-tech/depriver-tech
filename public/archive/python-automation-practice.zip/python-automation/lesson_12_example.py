# Python for Automation: Logs and useful summaries
import logging, io
stream = io.StringIO()
logger = logging.getLogger("notebook-demo")
logger.handlers.clear()
logger.setLevel(logging.INFO)
logger.addHandler(logging.StreamHandler(stream))
logger.info("processed=%s skipped=%s", 3, 1)
assert "processed=3 skipped=1" in stream.getvalue()
