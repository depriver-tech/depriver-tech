# Python for Automation: Duplicates and hashes
from hashlib import sha256

def digest(chunks):
    value = sha256()
    for chunk in chunks:
        value.update(chunk)
    return value.hexdigest()
assert digest([b"ab", b"cd"]) == sha256(b"abcd").hexdigest()
