# Python for Automation: Project: a folder reporter
from pathlib import Path
from tempfile import TemporaryDirectory
import csv

def build(root, target):
    with target.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["name", "bytes"])
        for path in sorted(root.iterdir()):
            if path.is_file() and not path.is_symlink():
                writer.writerow([path.name, path.stat().st_size])
with TemporaryDirectory() as folder:
    root = Path(folder)/"input"
    root.mkdir()
    (root/"a.txt").write_bytes(b"abc")
    (root/"b.txt").write_bytes(b"hello")
    (root/"subdir").mkdir()
    target = Path(folder)/"report.csv"
    build(root, target)
    first = target.read_bytes()
    build(root, target)
    assert target.read_bytes() == first
    assert (root/"a.txt").read_bytes() == b"abc"
    assert len(target.read_text().splitlines()) == 3
