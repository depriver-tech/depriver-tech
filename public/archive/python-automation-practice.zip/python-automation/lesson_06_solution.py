# Python for Automation: JSON configuration
def validate_config(data):
    if set(data) - {"minimum_bytes", "recursive"}:
        raise ValueError("Unknown option")
    size = data.get("minimum_bytes", 0)
    recursive = data.get("recursive", False)
    if type(size) is not int or size < 0:
        raise ValueError("Invalid minimum_bytes")
    if type(recursive) is not bool:
        raise ValueError("Invalid recursive")
    return {"minimum_bytes": size, "recursive": recursive}
assert validate_config({}) == {"minimum_bytes": 0, "recursive": False}
try:
    validate_config({"minimum_bytes": True})
except ValueError:
    pass
else:
    raise AssertionError("Boolean accepted as byte count")
