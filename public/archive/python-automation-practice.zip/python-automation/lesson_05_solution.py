# Python for Automation: CSV reports
import csv, io

def totals(source):
    result = {}
    for row in csv.DictReader(io.StringIO(source)):
        category = row["category"].strip()
        amount = int(row["amount"])
        if not category or amount < 0:
            raise ValueError("Invalid row")
        result[category] = result.get(category, 0) + amount
    return result
assert totals("category,amount\nfood,3000\nfood,2000\n") == {
    "food": 5000}
