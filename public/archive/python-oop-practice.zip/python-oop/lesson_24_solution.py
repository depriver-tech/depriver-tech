# Object-Oriented Python: Capstone: boundaries and review
# This exercise uses the companion capstone module.
from capstone import Book, Library

def summary(library):
    borrowed = len(library.active_loans())
    return {"available": len(library) - borrowed,
            "borrowed": borrowed}

library = Library()
library.add(Book("P1", "Python"))
library.add(Book("G1", "Git"))
assert summary(library) == {"available": 2, "borrowed": 0}
library.lend("P1", "Asha")
assert summary(library) == {"available": 1, "borrowed": 1}
library.return_book("P1")
assert summary(library) == {"available": 2, "borrowed": 0}
