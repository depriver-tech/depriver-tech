# Object-Oriented Python: Representations and equality
class Label:
    def __init__(self, text):
        self.text = text

    def __str__(self):
        return self.text

    def __repr__(self):
        return f"Label({self.text!r})"

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return self.text == other.text

assert str(Label("Python")) == "Python"
assert repr(Label("Python")) == "Label('Python')"
assert Label("Python") == Label("Python")
assert Label("Python") != "Python"
