# Object-Oriented Python: Composition: objects together
class FixedPrice:
    def price(self, quantity):
        return quantity * 500

class Checkout:
    def __init__(self, policy):
        self.policy = policy

    def total(self, quantity):
        return self.policy.price(quantity)

checkout = Checkout(FixedPrice())
assert checkout.total(0) == 0
assert checkout.total(3) == 1500
