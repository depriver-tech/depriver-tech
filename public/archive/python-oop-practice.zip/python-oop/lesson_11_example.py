# Object-Oriented Python: Representations and equality
class BookCode:
    def __init__(self, value):
        self.value = value

    def __repr__(self):
        return f"BookCode({self.value!r})"

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return self.value == other.value

a, b = BookCode("P1"), BookCode("P1")
assert a == b and a is not b
assert repr(a) == "BookCode('P1')"
