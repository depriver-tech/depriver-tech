# Object-Oriented Python: Multiple inheritance and MRO
class End:
    def run(self):
        return ["done"]
class Validate(End):
    def run(self):
        return ["validate"] + super().run()
class Record(End):
    def run(self):
        return ["record"] + super().run()
class Pipeline(Validate, Record):
    pass
class Reversed(Record, Validate):
    pass

assert Pipeline().run() == ["validate", "record", "done"]
assert Reversed().run() == ["record", "validate", "done"]
assert [c.__name__ for c in Pipeline.__mro__][:3] == [
    "Pipeline", "Validate", "Record"]
