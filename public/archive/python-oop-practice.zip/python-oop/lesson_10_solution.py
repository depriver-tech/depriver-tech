# Object-Oriented Python: ABCs and structural protocols
from typing import Protocol

class Formatter(Protocol):
    def format(self, title: str) -> str: ...

class PrefixFormatter:
    def format(self, title: str) -> str:
        return "Read: " + title

def make_label(formatter: Formatter, title: str) -> str:
    return formatter.format(title)

assert make_label(PrefixFormatter(), "Git") == "Read: Git"
