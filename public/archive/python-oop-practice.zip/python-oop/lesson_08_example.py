# Object-Oriented Python: Inheritance and substitution
class Notice:
    def render(self):
        return "Library closes at 17:00"

class UrgentNotice(Notice):
    def render(self):
        return "URGENT: " + super().render()

def display(notice):
    return notice.render()

assert display(UrgentNotice()).startswith("URGENT:")
assert display(Notice()) == "Library closes at 17:00"
