# Object-Oriented Python: Data classes and value objects
from dataclasses import dataclass, field

@dataclass
class ReadingList:
    owner: str
    titles: list[str] = field(default_factory=list)

a = ReadingList("Asha")
b = ReadingList("Asha")
assert a == b
assert a.titles is not b.titles
a.titles.append("Python")
assert b.titles == []
assert a != b
