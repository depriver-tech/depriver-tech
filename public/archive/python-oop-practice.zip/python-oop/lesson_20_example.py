# Object-Oriented Python: Descriptors and attribute lookup
class Upper:
    def __set_name__(self, owner, name):
        self.storage = "_" + name

    def __get__(self, obj, owner=None):
        if obj is None:
            return self
        return getattr(obj, self.storage)

    def __set__(self, obj, value):
        setattr(obj, self.storage, value.upper())

class Label:
    text = Upper()
    def __init__(self, text):
        self.text = text

assert Label("python").text == "PYTHON"
