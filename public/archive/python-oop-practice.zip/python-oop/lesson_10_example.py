# Object-Oriented Python: ABCs and structural protocols
from abc import ABC, abstractmethod

class Exporter(ABC):
    @abstractmethod
    def export(self, title):
        raise NotImplementedError

class TextExporter(Exporter):
    def export(self, title):
        return title + "\n"

assert TextExporter().export("Python") == "Python\n"
