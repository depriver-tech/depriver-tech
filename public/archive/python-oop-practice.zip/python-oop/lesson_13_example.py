# Object-Oriented Python: Collections and iteration
class Shelf:
    def __init__(self, titles):
        self._titles = tuple(titles)

    def __len__(self):
        return len(self._titles)

    def __iter__(self):
        return iter(self._titles)

    def __contains__(self, title):
        return title in self._titles

shelf = Shelf(["Git", "Python"])
assert len(shelf) == 2
assert list(shelf) == ["Git", "Python"]
assert "Git" in shelf
