# Object-Oriented Python: Dependencies and test doubles
class ReminderService:
    def __init__(self, sender):
        self.sender = sender

    def remind(self, name):
        self.sender.send("Return your book, " + name)

class FakeSender:
    def __init__(self):
        self.messages = []
    def send(self, message):
        self.messages.append(message)

sender = FakeSender()
ReminderService(sender).remind("Asha")
assert sender.messages == ["Return your book, Asha"]
