# Object-Oriented Python: Start with ordinary Python
def completed_count(learner):
    return len(learner["topics"])

empty = {"name": "Asha", "topics": []}
ready = {"name": "Juma", "topics": ["Git", "Python"]}
assert completed_count(empty) == 0
assert completed_count(ready) == 2
assert ready["topics"] == ["Git", "Python"]
