# Object-Oriented Python: Errors and atomic state changes
class InsufficientCredits(Exception):
    pass

class Account:
    def __init__(self, balance):
        if type(balance) is not int or balance < 0:
            raise ValueError("invalid balance")
        self.balance = balance

    def spend(self, amount):
        if type(amount) is not int or amount <= 0:
            raise ValueError("invalid amount")
        if amount > self.balance:
            raise InsufficientCredits("not enough credits")
        self.balance -= amount

account = Account(5)
account.spend(3)
assert account.balance == 2
