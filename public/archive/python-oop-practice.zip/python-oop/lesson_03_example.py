# Object-Oriented Python: State and useful methods
class Counter:
    def __init__(self):
        self.value = 0

    def increment(self):
        self.value += 1
        return self.value

counter = Counter()
assert counter.increment() == 1
assert counter.increment() == 2
