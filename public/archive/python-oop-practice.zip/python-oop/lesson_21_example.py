# Object-Oriented Python: Construction hooks and metaclasses
class Plugin:
    registry = {}

    def __init_subclass__(cls, *, key, **kwargs):
        super().__init_subclass__(**kwargs)
        if key in Plugin.registry:
            raise ValueError("duplicate plugin key")
        Plugin.registry[key] = cls

class TextPlugin(Plugin, key="text"):
    pass

assert Plugin.registry["text"] is TextPlugin
assert isinstance(TextPlugin, type)
