# Object-Oriented Python: Design principles and strategies
class ReceiptRenderer:
    def __init__(self, format_titles):
        self.format_titles = format_titles

    def render(self, titles):
        return self.format_titles(titles)

def plain(titles):
    return ", ".join(titles)

def bullets(titles):
    return "\n".join("- " + title for title in titles)

assert ReceiptRenderer(plain).render(["Git", "Python"]) == "Git, Python"
assert ReceiptRenderer(bullets).render(["Git"]) == "- Git"
