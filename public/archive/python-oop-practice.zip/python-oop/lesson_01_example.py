# Object-Oriented Python: Start with ordinary Python
def greet(learner):
    return "Hello, " + learner["name"]

learner = {"name": "Asha", "topics": []}
learner["topics"].append("Python")
assert greet(learner) == "Hello, Asha"
assert len(learner["topics"]) == 1
print(greet(learner))
