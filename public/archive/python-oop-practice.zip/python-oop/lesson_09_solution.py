# Object-Oriented Python: Polymorphism and duck typing
class RecordingSender:
    def __init__(self):
        self.messages = []

    def send(self, text):
        self.messages.append(text)

class UpperSender(RecordingSender):
    def send(self, text):
        self.messages.append(text.upper())

def notify(sender, text):
    sender.send(text)

a, b = RecordingSender(), UpperSender()
notify(a, "hello")
notify(b, "hello")
assert a.messages == ["hello"]
assert b.messages == ["HELLO"]
