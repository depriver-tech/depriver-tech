# Object-Oriented Python: Composition: objects together
class Catalogue:
    def title_for(self, code):
        return {"P1": "Python"}[code]

class ReadingDesk:
    def __init__(self, catalogue):
        self.catalogue = catalogue

    def recommend(self, code):
        return "Read " + self.catalogue.title_for(code)

desk = ReadingDesk(Catalogue())
assert desk.recommend("P1") == "Read Python"
