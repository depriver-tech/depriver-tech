# Object-Oriented Python: Multiple inheritance and MRO
class End:
    def steps(self):
        return ["end"]

class Audit(End):
    def steps(self):
        return ["audit"] + super().steps()

class Cache(End):
    def steps(self):
        return ["cache"] + super().steps()

class Service(Audit, Cache):
    pass

assert Service().steps() == ["audit", "cache", "end"]
