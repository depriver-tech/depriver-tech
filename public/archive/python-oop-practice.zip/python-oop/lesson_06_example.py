# Object-Oriented Python: Factories and method types
class Book:
    def __init__(self, title):
        self.title = title

    @classmethod
    def from_line(cls, line):
        return cls(line.strip())

    @staticmethod
    def valid_title(title):
        return bool(title.strip())

assert Book.from_line(" Python ").title == "Python"
assert not Book.valid_title("   ")
