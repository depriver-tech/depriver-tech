# Object-Oriented Python: Memory, copying and slots
from dataclasses import dataclass

@dataclass(slots=True)
class Point:
    x: int
    y: int

point = Point(2, 3)
assert not hasattr(point, "__dict__")
try:
    point.z = 4
except AttributeError:
    pass
else:
    raise AssertionError("unexpected attribute")
