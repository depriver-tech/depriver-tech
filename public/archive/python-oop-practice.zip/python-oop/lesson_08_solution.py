# Object-Oriented Python: Inheritance and substitution
class Report:
    def __init__(self, title):
        self.title = title

    def heading(self):
        return "Report"

class StudyReport(Report):
    def heading(self):
        return "Study: " + self.title

base = Report("Week 1")
report = StudyReport("Week 1")
assert base.heading() == "Report"
assert report.heading() == "Study: Week 1"
assert report.title == base.title
