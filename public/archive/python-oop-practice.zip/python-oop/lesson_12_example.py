# Object-Oriented Python: Data classes and value objects
from dataclasses import dataclass

@dataclass(frozen=True)
class BookCode:
    value: str

    def __post_init__(self):
        if not self.value.strip():
            raise ValueError("empty book code")

assert BookCode("P1") == BookCode("P1")
assert len({BookCode("P1"), BookCode("P1")}) == 1
