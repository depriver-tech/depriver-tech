# Object-Oriented Python: Construction hooks and metaclasses
class Named(type):
    def __new__(mcls, name, bases, namespace):
        label = namespace.get("label")
        if not isinstance(label, str) or not label.strip():
            raise TypeError("label required")
        return super().__new__(mcls, name, bases, namespace)

class TextFormat(metaclass=Named):
    label = "text"

assert TextFormat.label == "text"
try:
    class Missing(metaclass=Named):
        pass
except TypeError:
    pass
else:
    raise AssertionError("missing label accepted")
