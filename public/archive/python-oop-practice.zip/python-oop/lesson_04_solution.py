# Object-Oriented Python: Instance data and shared data
class StudyGroup:
    def __init__(self, members=None):
        self.members = [] if members is None else list(members)

    def add(self, name):
        self.members.append(name)

source = ["Asha"]
a = StudyGroup(source)
b = StudyGroup()
source.append("Juma")
a.add("Neema")
assert a.members == ["Asha", "Neema"]
assert b.members == []
