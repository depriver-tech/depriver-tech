# Object-Oriented Python: Classes, objects and self
class Learner:
    def __init__(self, name):
        self.name = name

    def introduce(self):
        return "I am " + self.name

a = Learner("Asha")
b = Learner("Juma")
assert a.introduce() == "I am Asha"
assert b.introduce() == "I am Juma"
a.name = "Neema"
assert b.name == "Juma"
