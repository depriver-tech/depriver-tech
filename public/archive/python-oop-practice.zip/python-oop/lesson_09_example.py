# Object-Oriented Python: Polymorphism and duck typing
class Plain:
    def format(self, title):
        return title

class Bracketed:
    def format(self, title):
        return "[" + title + "]"

def label(formatter, title):
    return formatter.format(title)

assert label(Plain(), "Python") == "Python"
assert label(Bracketed(), "Python") == "[Python]"
