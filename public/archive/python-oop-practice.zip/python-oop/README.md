# Object-Oriented Python - practice files

By Privatus Cosmas (Priver), depriver.tech. Companion to the 80-page notebook.

## Setup

Install Python 3.11 or newer. Open a terminal in the extracted practice folder; on Windows, use py instead of python if needed. Use a text editor and save files with a .py extension. Examples use only the standard library. Tested versions are recorded in verification.json.

```sh
python --version
python lesson_01_example.py
python lesson_01_solution.py
python -m unittest discover -s . -v
```

Create a virtual environment before installing third-party packages:

```sh
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
```

There are 24 example scripts and 24 matching solutions. Run each file on its own.
Most successful checks print nothing; a failed assertion produces a traceback.
Read the lesson before its solution. lesson.md provides the complete text.

These are local educational fixtures. No live service credentials are needed.
Tests establish the demonstrated examples, not production readiness. Browser,
network, deployment and security review remain separate work for a real app.

## Official references

- [Python language: classes and objects](https://docs.python.org/3/tutorial/classes.html)
- [Special methods and object contracts](https://docs.python.org/3/reference/datamodel.html)
- [Data classes](https://docs.python.org/3/library/dataclasses.html)
- [Descriptors: advanced attribute behaviour](https://docs.python.org/3/howto/descriptor.html)

## Complete lending project

Run `python capstone.py` for the local demonstration.
Run `python -m unittest discover -s . -v` for 16 capstone tests.
Expected demo:

```
Active loans: {'P1': 'Asha'}
Returned by: Asha
Python available: True
```

Keep all files together: lesson_24_solution.py imports capstone.py.
Do not run examples with `python -O`, which disables plain assert checks.
No packages need installing for practice. The PDF builder separately needs
ReportLab; learners do not need that builder to study this book.

This is a single-process, in-memory model. It has no database persistence,
web authentication, concurrent-transaction guarantee or external integrations.
`verification.json` records the interpreter and actual script/test results.
Python 3.11-compatible syntax is used, but only the recorded interpreter was tested.

## Project contract

Book code identifies one physical copy. Codes and titles are stripped and
must be non-empty strings. add() rejects duplicate codes. Unknown codes raise
KeyError. A conflicting loan or invalid return raises LoanError. Invalid
borrower text raises ValueError. Rejected operations preserve existing loans.
active_loans() returns a defensive snapshot. Separate Library objects do not
share state. Book records are frozen; UI and storage remain separate concerns.
