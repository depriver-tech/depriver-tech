# Object-Oriented Python: Dependencies and test doubles
from datetime import date

class FixedClock:
    def today(self):
        return date(2026, 10, 24)

class DueChecker:
    def __init__(self, clock):
        self.clock = clock

    def overdue(self, due):
        return due < self.clock.today()

checker = DueChecker(FixedClock())
assert checker.overdue(date(2026, 10, 23))
assert not checker.overdue(date(2026, 10, 24))
assert not checker.overdue(date(2026, 10, 25))
