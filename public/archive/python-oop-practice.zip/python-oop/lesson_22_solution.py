# Object-Oriented Python: Memory, copying and slots
from copy import deepcopy

plan = [["Python"]]
alias = plan
shallow = plan.copy()
deep = deepcopy(plan)
plan[0].append("Git")

assert alias is plan
assert shallow is not plan
assert shallow[0] is plan[0]
assert shallow == [["Python", "Git"]]
assert deep == [["Python"]]
assert deep[0] is not plan[0]
