# Object-Oriented Python: Capstone: boundaries and review
class MemoryTitles:
    def __init__(self):
        self._items = {}
    def add(self, code, title):
        self._items[code] = title
    def get(self, code):
        return self._items[code]

class TitleService:
    def __init__(self, repository):
        self.repository = repository
    def label(self, code):
        return "Read: " + self.repository.get(code)

repo = MemoryTitles()
repo.add("P1", "Python")
assert TitleService(repo).label("P1") == "Read: Python"
