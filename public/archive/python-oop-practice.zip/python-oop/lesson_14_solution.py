# Object-Oriented Python: Context managers and cleanup
class RecordingScope:
    def __init__(self, events):
        self.events = events

    def __enter__(self):
        self.events.append("enter")
        return self

    def __exit__(self, *error):
        self.events.append("exit")
        return False

events = []
try:
    with RecordingScope(events):
        raise ValueError("example")
except ValueError:
    pass
else:
    raise AssertionError("error suppressed")
assert events == ["enter", "exit"]
