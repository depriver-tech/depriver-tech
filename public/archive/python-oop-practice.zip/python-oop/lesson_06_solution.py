# Object-Oriented Python: Factories and method types
class Coordinate:
    def __init__(self, x, y):
        self.x, self.y = x, y

    @classmethod
    def from_text(cls, text):
        x, y = text.split(",")
        return cls(int(x), int(y))

point = Coordinate.from_text("3, 4")
assert (point.x, point.y) == (3, 4)
class ScreenPoint(Coordinate):
    pass
assert isinstance(ScreenPoint.from_text("1,2"), ScreenPoint)
