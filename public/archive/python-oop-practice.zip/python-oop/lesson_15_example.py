# Object-Oriented Python: Errors and atomic state changes
class UnavailableError(Exception):
    pass

class Copy:
    def __init__(self):
        self.borrower = None

    def lend(self, borrower):
        if self.borrower is not None:
            raise UnavailableError("already on loan")
        self.borrower = borrower

copy = Copy()
copy.lend("Asha")
assert copy.borrower == "Asha"
