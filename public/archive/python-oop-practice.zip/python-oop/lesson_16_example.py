# Object-Oriented Python: Test behaviour, not internals
import unittest

class Counter:
    def __init__(self):
        self.value = 0

    def increment(self):
        self.value += 1

class CounterTests(unittest.TestCase):
    def test_increment(self):
        counter = Counter()
        counter.increment()
        self.assertEqual(counter.value, 1)

if __name__ == "__main__":
    unittest.main()
