# Object-Oriented Python: Test behaviour, not internals
import unittest

class Gate:
    def __init__(self):
        self.is_open = False
    def open(self):
        self.is_open = True
    def enter(self):
        if not self.is_open:
            raise ValueError("closed")
        return "welcome"

class GateTests(unittest.TestCase):
    def test_closed(self):
        with self.assertRaises(ValueError):
            Gate().enter()
    def test_open(self):
        gate = Gate()
        gate.open()
        self.assertEqual(gate.enter(), "welcome")

if __name__ == "__main__":
    unittest.main()
