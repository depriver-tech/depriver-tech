# Object-Oriented Python: Context managers and cleanup
class Session:
    def __init__(self):
        self.closed = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.closed = True
        return False

with Session() as session:
    assert not session.closed
assert session.closed
