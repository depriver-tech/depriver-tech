# Object-Oriented Python: Descriptors and attribute lookup
class NonNegative:
    def __set_name__(self, owner, name):
        self.key = "_" + name
    def __get__(self, obj, owner=None):
        return self if obj is None else getattr(obj, self.key)
    def __set__(self, obj, value):
        if type(value) is not int or value < 0:
            raise ValueError("non-negative integer required")
        setattr(obj, self.key, value)

class Inventory:
    quantity = NonNegative()
    def __init__(self, quantity):
        self.quantity = quantity

a, b = Inventory(3), Inventory(7)
a.quantity = 2
assert (a.quantity, b.quantity) == (2, 7)
