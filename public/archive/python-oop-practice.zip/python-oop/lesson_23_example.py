# Object-Oriented Python: Capstone: a lending domain
from dataclasses import dataclass

@dataclass(frozen=True)
class Book:
    code: str
    title: str

class Catalogue:
    def __init__(self):
        self._books = {}
    def add(self, book):
        if book.code in self._books:
            raise ValueError("duplicate code")
        self._books[book.code] = book
    def get(self, code):
        return self._books[code]

catalogue = Catalogue()
catalogue.add(Book("P1", "Python"))
assert catalogue.get("P1").title == "Python"
