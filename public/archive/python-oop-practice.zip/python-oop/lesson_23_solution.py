# Object-Oriented Python: Capstone: a lending domain
class LoanRegister:
    def __init__(self):
        self._loans = {}
    def lend(self, code, borrower):
        if not isinstance(borrower, str) or not borrower.strip():
            raise ValueError("borrower required")
        if code in self._loans:
            raise ValueError("already lent")
        self._loans[code] = borrower.strip()
    def return_book(self, code):
        if code not in self._loans:
            raise ValueError("not on loan")
        return self._loans.pop(code)
    def borrower_for(self, code):
        return self._loans.get(code)

loans = LoanRegister()
loans.lend("P1", "Asha")
assert loans.borrower_for("P1") == "Asha"
assert loans.return_book("P1") == "Asha"
assert loans.borrower_for("P1") is None
