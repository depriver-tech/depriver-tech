# Object-Oriented Python: Collections and iteration
class Countdown:
    def __init__(self, start):
        if type(start) is not int or start < 0:
            raise ValueError("non-negative integer required")
        self.start = start

    def __iter__(self):
        for value in range(self.start, 0, -1):
            yield value

countdown = Countdown(3)
assert list(countdown) == [3, 2, 1]
assert list(countdown) == [3, 2, 1]
assert list(Countdown(0)) == []
