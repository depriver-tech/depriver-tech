# Object-Oriented Python: Classes, objects and self
class Book:
    def __init__(self, title):
        self.title = title

    def label(self):
        return "Book: " + self.title

first = Book("Python")
second = Book("Git")
assert first.label() == "Book: Python"
assert second.title == "Git"
assert first is not second
