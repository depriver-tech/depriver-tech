# Object-Oriented Python: Design principles and strategies
def standard_days(member):
    return 14

def student_days(member):
    return 21

class LoanPolicy:
    def __init__(self, days_for):
        self.days_for = days_for

    def duration(self, member):
        return self.days_for(member)

assert LoanPolicy(standard_days).duration("Asha") == 14
assert LoanPolicy(student_days).duration("Asha") == 21
