# Object-Oriented Python: State and useful methods
class ReadingProgress:
    def __init__(self):
        self.pages = 0

    def advance(self, pages):
        if type(pages) is not int or pages <= 0:
            raise ValueError("positive integer required")
        self.pages += pages
        return self.pages

p = ReadingProgress()
assert p.advance(3) == 3
assert p.advance(2) == 5
try:
    p.advance(0)
except ValueError:
    pass
else:
    raise AssertionError("zero accepted")
assert p.pages == 5
