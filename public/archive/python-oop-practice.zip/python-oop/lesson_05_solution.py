# Object-Oriented Python: Encapsulation and properties
class Stock:
    def __init__(self, quantity):
        if type(quantity) is not int or quantity < 0:
            raise ValueError("invalid quantity")
        self._quantity = quantity

    @property
    def quantity(self):
        return self._quantity

    def remove(self, amount):
        if type(amount) is not int or amount <= 0:
            raise ValueError("invalid amount")
        if amount > self._quantity:
            raise ValueError("insufficient stock")
        self._quantity -= amount

stock = Stock(3)
stock.remove(2)
assert stock.quantity == 1
