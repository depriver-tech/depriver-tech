# Object-Oriented Python: Instance data and shared data
class Shelf:
    category = "learning"

    def __init__(self):
        self.titles = []

left = Shelf()
right = Shelf()
left.titles.append("Python")
assert right.titles == []
assert left.category == right.category == "learning"
