# Python with DSA: Binary search
from bisect import bisect_left, bisect_right

def count_target(values, target):
    return bisect_right(values, target) - bisect_left(
        values, target)

assert count_target([1, 3, 3, 3, 7], 3) == 3
assert count_target([1, 2], 5) == 0
assert count_target([], 1) == 0
