# Python with DSA: Dynamic programming
def stair_ways(n):
    if n < 0:
        raise ValueError("n must be non-negative")
    previous, current = 1, 1
    for _ in range(n):
        previous, current = current, previous + current
    return previous

assert stair_ways(0) == 1
assert stair_ways(4) == 5
