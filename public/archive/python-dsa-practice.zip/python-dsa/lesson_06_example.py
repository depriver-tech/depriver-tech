# Python with DSA: Stacks and matching
history = []
history.append("typed title")
history.append("added paragraph")
assert history.pop() == "added paragraph"
assert history.pop() == "typed title"
assert not history
