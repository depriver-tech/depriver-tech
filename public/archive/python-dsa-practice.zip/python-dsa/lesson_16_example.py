# Python with DSA: Greedy interval choices
def select_intervals(intervals):
    selected, end = [], float("-inf")
    for start, finish in sorted(intervals,
                                key=lambda pair: pair[1]):
        if start >= end:
            selected.append((start, finish))
            end = finish
    return selected

assert select_intervals([(0, 3), (1, 2), (2, 4)]) == [
    (1, 2), (2, 4)]
