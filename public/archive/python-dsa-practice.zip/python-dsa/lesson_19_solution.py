# Python with DSA: Sliding windows and prefixes
def max_window(values, k):
    if not 1 <= k <= len(values):
        raise ValueError("Invalid window size")
    current = best = sum(values[:k])
    for i in range(k, len(values)):
        current += values[i] - values[i-k]
        best = max(best, current)
    return best

assert max_window([2, 5, 1, 4], 2) == 7
assert max_window([-5, -2, -7], 2) == -7
