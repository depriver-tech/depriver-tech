# Python with DSA: Linked structures
class Node:
    def __init__(self, value, next_node=None):
        self.value, self.next = value, next_node

def reverse(head):
    previous, current = None, head
    while current is not None:
        following = current.next
        current.next = previous
        previous, current = current, following
    return previous

head = reverse(Node(1, Node(2, Node(3))))
assert [head.value, head.next.value,
        head.next.next.value] == [3, 2, 1]
assert reverse(None) is None
