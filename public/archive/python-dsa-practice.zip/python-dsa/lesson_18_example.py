# Python with DSA: Backtracking
def subsets(values):
    result = [[]]
    for value in values:
        result += [part + [value] for part in result]
    return result

assert subsets([1, 2]) == [[], [1], [2], [1, 2]]
assert subsets([]) == [[]]
