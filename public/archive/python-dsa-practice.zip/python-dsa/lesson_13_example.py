# Python with DSA: Graphs and breadth-first search
from collections import deque

def distances(graph, start):
    result, queue = {start: 0}, deque([start])
    while queue:
        node = queue.popleft()
        for neighbour in graph.get(node, []):
            if neighbour not in result:
                result[neighbour] = result[node] + 1
                queue.append(neighbour)
    return result

g = {"A": ["B"], "B": ["A", "C"], "C": []}
assert distances(g, "A") == {"A": 0, "B": 1, "C": 2}
