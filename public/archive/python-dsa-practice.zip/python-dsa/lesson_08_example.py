# Python with DSA: Binary search
def lower_bound(values, target):
    low, high = 0, len(values)
    while low < high:
        mid = (low + high) // 2
        if values[mid] < target:
            low = mid + 1
        else:
            high = mid
    return low

assert lower_bound([1, 3, 3, 7], 3) == 1
assert lower_bound([], 4) == 0
