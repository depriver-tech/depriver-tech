# Python with DSA: Sliding windows and prefixes
def prefix_sums(values):
    prefix = [0]
    for value in values:
        prefix.append(prefix[-1] + value)
    return prefix

p = prefix_sums([2, 5, 1, 4])
assert p[3] - p[1] == 6
assert p[4] - p[0] == 12
