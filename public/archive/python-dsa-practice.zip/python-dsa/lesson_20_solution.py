# Python with DSA: Project: a task planner
import heapq

class Planner:
    def __init__(self):
        self.tasks, self.queue = {}, []
    def add(self, ident, title, priority):
        if ident in self.tasks:
            raise ValueError("Duplicate id")
        self.tasks[ident] = title
        heapq.heappush(self.queue, (priority, ident))
    def cancel(self, ident):
        return self.tasks.pop(ident, None) is not None
    def take(self):
        while self.queue:
            _, ident = heapq.heappop(self.queue)
            if ident in self.tasks:
                return ident, self.tasks.pop(ident)
        return None

p = Planner()
p.add(1, "A", 1)
p.add(2, "B", 2)
assert p.cancel(1)
assert p.take() == (2, "B")
assert p.take() is None
