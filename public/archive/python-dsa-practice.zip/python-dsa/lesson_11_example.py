# Python with DSA: Linked structures
class Node:
    def __init__(self, value, next_node=None):
        self.value = value
        self.next = next_node

head = Node(1, Node(2, Node(3)))
values, node = [], head
while node is not None:
    values.append(node.value)
    node = node.next
assert values == [1, 2, 3]
