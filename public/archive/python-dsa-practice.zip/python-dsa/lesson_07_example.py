# Python with DSA: Queues and scheduling
from collections import deque

jobs = deque(["scan", "resize", "report"])
processed = []
while jobs:
    processed.append(jobs.popleft())
assert processed == ["scan", "resize", "report"]
