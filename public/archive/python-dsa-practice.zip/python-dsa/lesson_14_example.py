# Python with DSA: Depth-first search
def dfs(graph, start):
    seen, stack = set(), [start]
    while stack:
        node = stack.pop()
        if node in seen:
            continue
        seen.add(node)
        stack.extend(graph.get(node, []))
    return seen

assert dfs({1: [2], 2: [1, 3]}, 1) == {1, 2, 3}
