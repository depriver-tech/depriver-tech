# Python with DSA: Trees and traversal
def stats(node):
    if node is None:
        return 0, 0
    _, left, right = node
    lc, lh = stats(left)
    rc, rh = stats(right)
    return 1 + lc + rc, 1 + max(lh, rh)

tree = (4, (2, None, None), (7, None, None))
assert stats(None) == (0, 0)
assert stats((1, None, None)) == (1, 1)
assert stats(tree) == (3, 2)
