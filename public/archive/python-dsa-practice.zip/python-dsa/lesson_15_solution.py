# Python with DSA: Heaps and priorities
import heapq

def top_k(values, k):
    if k < 0:
        raise ValueError("k must not be negative")
    return heapq.nlargest(k, values)

assert top_k([4, 1, 7, 2], 2) == [7, 4]
assert top_k([3], 5) == [3]
assert top_k([3], 0) == []
