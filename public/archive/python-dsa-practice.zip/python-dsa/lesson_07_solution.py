# Python with DSA: Queues and scheduling
from collections import deque

def finish_order(jobs):
    if any(units <= 0 for _, units in jobs):
        raise ValueError("Positive work required")
    queue, done = deque(jobs), []
    while queue:
        name, units = queue.popleft()
        if units == 1:
            done.append(name)
        else:
            queue.append((name, units - 1))
    return done

assert finish_order([("A", 2), ("B", 1)]) == ["B", "A"]
assert finish_order([]) == []
