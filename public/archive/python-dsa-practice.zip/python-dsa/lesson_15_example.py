# Python with DSA: Heaps and priorities
import heapq

jobs = []
heapq.heappush(jobs, (2, 0, "report"))
heapq.heappush(jobs, (1, 1, "urgent"))
heapq.heappush(jobs, (2, 2, "backup"))
assert heapq.heappop(jobs)[2] == "urgent"
assert heapq.heappop(jobs)[2] == "report"
