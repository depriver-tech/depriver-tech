# Python with DSA: Lists and copying
values = [4, 7, 9]
alias = values
copy = values.copy()
alias.append(12)
assert values == [4, 7, 9, 12]
assert copy == [4, 7, 9]
print(values, copy)
