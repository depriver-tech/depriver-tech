# Python with DSA: Project: a task planner
import heapq

class Planner:
    def __init__(self):
        self.tasks, self.queue = {}, []
    def add(self, task_id, title, priority):
        if task_id in self.tasks:
            raise ValueError("Duplicate task id")
        self.tasks[task_id] = title
        heapq.heappush(self.queue, (priority, task_id))
    def take(self):
        if not self.queue:
            return None
        _, task_id = heapq.heappop(self.queue)
        return task_id, self.tasks.pop(task_id)

p = Planner()
p.add(1, "Write tests", 2)
p.add(2, "Fix error", 1)
assert p.take() == (2, "Fix error")
