# Python with DSA: Sorting with a purpose
rows = [("Asha", 80), ("Juma", 90), ("Neema", 80)]
ranked = sorted(rows, key=lambda row: -row[1])
assert ranked == [("Juma", 90), ("Asha", 80),
                  ("Neema", 80)]
assert rows[0] == ("Asha", 80)
