# Python with DSA: Graphs and breadth-first search
from collections import deque

def reachable(graph, start):
    seen, queue = {start}, deque([start])
    while queue:
        for nxt in graph.get(queue.popleft(), []):
            if nxt not in seen:
                seen.add(nxt)
                queue.append(nxt)
    return seen

assert reachable({"A": ["B"], "B": ["A"]}, "A") == {
    "A", "B"}
assert reachable({}, "Z") == {"Z"}
