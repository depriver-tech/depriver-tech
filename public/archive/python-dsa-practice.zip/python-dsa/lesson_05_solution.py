# Python with DSA: Sets and membership
def has_pair(values, target):
    seen = set()
    for value in values:
        if target - value in seen:
            return True
        seen.add(value)
    return False

assert has_pair([2, 7, 11], 9)
assert not has_pair([4], 8)
assert has_pair([4, 4], 8)
assert not has_pair([], 0)
