# Python with DSA: Trees and traversal
tree = (4, (2, None, None), (7, None, None))

def inorder(node):
    if node is None:
        return []
    value, left, right = node
    return inorder(left) + [value] + inorder(right)

assert inorder(tree) == [2, 4, 7]
