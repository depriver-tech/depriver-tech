# Python with DSA: Greedy interval choices
def greedy_change(amount, coins):
    chosen = []
    for coin in sorted(coins, reverse=True):
        while amount >= coin:
            chosen.append(coin)
            amount -= coin
    return chosen, amount

chosen, rest = greedy_change(6, [1, 3, 4])
assert chosen == [4, 1, 1] and rest == 0
better = [3, 3]
assert sum(better) == 6
assert len(better) < len(chosen)
