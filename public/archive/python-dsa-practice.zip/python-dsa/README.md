# Python with DSA - practice files

By Privatus Cosmas (Priver), depriver.tech. Companion to the 64-page notebook.

## Setup

Create a folder named python-dsa. Use Python 3.11 or newer and a text editor. Each example and solution is independent. Run a file with python lesson_01_example.py. Assertions check expected results and remain silent when they pass. Use a disposable folder for your work.

```sh
python --version
python lesson_01_example.py
python lesson_01_solution.py
```

Create a virtual environment before installing third-party packages:

```sh
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
```

There are 20 example scripts and 20 matching solutions. Run each file on its own.
Most successful checks print nothing; a failed assertion produces a traceback.
Read the lesson before its solution. lesson.md provides the complete text.

These are local educational fixtures. No live service credentials are needed.
Tests establish the demonstrated examples, not production readiness. Browser,
network, deployment and security review remain separate work for a real app.

## Official references

- [Python data structures](https://docs.python.org/3/tutorial/datastructures.html)
- [Collections](https://docs.python.org/3/library/collections.html)
- [Binary search helpers](https://docs.python.org/3/library/bisect.html)
- [Heap queues](https://docs.python.org/3/library/heapq.html)
- [Sorting guide](https://docs.python.org/3/howto/sorting.html)
