# Python with DSA: Recursion and base cases
def nested_sum(value):
    if isinstance(value, int):
        return value
    return sum(nested_sum(item) for item in value)

assert nested_sum([1, [2, 3], []]) == 6
assert nested_sum([]) == 0
assert nested_sum([[-2], 5]) == 3
