# Python with DSA: Strings and two pointers
def palindrome(text):
    left, right = 0, len(text) - 1
    while left < right:
        if text[left] != text[right]:
            return False
        left += 1
        right -= 1
    return True

assert palindrome("level")
assert not palindrome("python")
assert palindrome("")
