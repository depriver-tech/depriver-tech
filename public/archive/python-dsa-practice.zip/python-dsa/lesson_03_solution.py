# Python with DSA: Strings and two pointers
def phrase_palindrome(text):
    clean = "".join(c.casefold() for c in text
                    if c.isalnum())
    return clean == clean[::-1]

assert phrase_palindrome("Never odd or even")
assert not phrase_palindrome("Python notes")
assert phrase_palindrome("!!!")
