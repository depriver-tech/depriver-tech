# Python with DSA: Lists and copying
def rotate_left(values, steps):
    if not values:
        return []
    k = steps % len(values)
    return values[k:] + values[:k]

source = [1, 2, 3]
assert rotate_left(source, 4) == [2, 3, 1]
assert rotate_left([], 5) == []
assert source == [1, 2, 3]
