# Python with DSA: Measure growth
def pair_count(values):
    count = 0
    for i in range(len(values)):
        for j in range(i + 1, len(values)):
            count += 1
    return count

assert pair_count([]) == 0
assert pair_count([1]) == 0
assert pair_count(range(4)) == 6
assert pair_count(range(8)) == 28
