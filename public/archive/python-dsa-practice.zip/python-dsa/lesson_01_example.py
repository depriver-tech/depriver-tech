# Python with DSA: Measure growth
def scan_count(values):
    count = 0
    for value in values:
        count += 1
    return count

assert scan_count(range(5)) == 5
assert scan_count(range(10)) == 10
print("Doubling input doubles visits")
