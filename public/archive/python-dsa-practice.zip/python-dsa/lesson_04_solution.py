# Python with DSA: Hash maps and counting
def first_unique(text):
    counts = {}
    for char in text:
        counts[char] = counts.get(char, 0) + 1
    for char in text:
        if counts[char] == 1:
            return char
    return None

assert first_unique("swiss") == "w"
assert first_unique("aabb") is None
assert first_unique("") is None
