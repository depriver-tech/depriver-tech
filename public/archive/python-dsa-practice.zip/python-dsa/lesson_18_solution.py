# Python with DSA: Backtracking
def binary_strings(n):
    if n < 0:
        raise ValueError("Negative length")
    result = []
    def visit(prefix):
        if len(prefix) == n:
            result.append(prefix)
            return
        visit(prefix + "0")
        if not prefix or prefix[-1] == "0":
            visit(prefix + "1")
    visit("")
    return result

assert binary_strings(2) == ["00", "01", "10"]
assert binary_strings(0) == [""]
