# Python with DSA: Stacks and matching
def balanced(text):
    stack = []
    for char in text:
        if char == "(":
            stack.append(char)
        elif char == ")":
            if not stack:
                return False
            stack.pop()
        else:
            raise ValueError("Only parentheses allowed")
    return not stack

assert balanced("(())()")
assert not balanced(")(")
assert not balanced("(()")
assert balanced("")
