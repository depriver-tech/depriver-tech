# Python with DSA: Hash maps and counting
def frequencies(words):
    counts = {}
    for word in words:
        counts[word] = counts.get(word, 0) + 1
    return counts

assert frequencies(["api", "web", "api"]) == {
    "api": 2, "web": 1
}
assert frequencies([]) == {}
