# Python with DSA: Sets and membership
def unique_in_order(values):
    seen, result = set(), []
    for value in values:
        if value not in seen:
            seen.add(value)
            result.append(value)
    return result

assert unique_in_order([3, 1, 3, 2]) == [3, 1, 2]
