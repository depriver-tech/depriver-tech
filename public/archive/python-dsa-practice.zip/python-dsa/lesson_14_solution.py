# Python with DSA: Depth-first search
def components(graph):
    seen, count = set(), 0
    for start in graph:
        if start in seen:
            continue
        count += 1
        stack = [start]
        while stack:
            node = stack.pop()
            if node not in seen:
                seen.add(node)
                stack.extend(graph[node])
    return count

assert components({1: [2], 2: [1], 3: []}) == 2
assert components({}) == 0
