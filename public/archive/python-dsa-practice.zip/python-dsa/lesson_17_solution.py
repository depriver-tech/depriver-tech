# Python with DSA: Dynamic programming
def min_coins(coins, amount):
    if amount < 0 or any(c <= 0 for c in coins):
        raise ValueError("Invalid amount or coin")
    dp = [0] + [float("inf")] * amount
    for total in range(1, amount + 1):
        for coin in coins:
            if coin <= total:
                dp[total] = min(dp[total], dp[total-coin] + 1)
    return None if dp[amount] == float("inf") else dp[amount]

assert min_coins([1, 3, 4], 6) == 2
assert min_coins([2], 3) is None
assert min_coins([2], 0) == 0
