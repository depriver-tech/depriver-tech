# Python with DSA: Sorting with a purpose
def insertion_sort(values):
    result = list(values)
    for i in range(1, len(result)):
        item, j = result[i], i - 1
        while j >= 0 and result[j] > item:
            result[j + 1] = result[j]
            j -= 1
        result[j + 1] = item
    return result

source = [3, 1, 2]
assert insertion_sort(source) == [1, 2, 3]
assert source == [3, 1, 2]
assert insertion_sort([]) == []
